Penjelasan singkat yang muncul di atas elemen saat disorot. Hanya untuk tablet dan desktop yang memiliki hover; di mobile informasi yang sama harus tampak langsung atau ada di [Sheet](../Sheet). **Usulan.**

**Susunan:** gelembung `ev-purple-900`, teks putih 12/500, padding 6x10px, radius `ev-r-md`, maksimal lebar 240px, panah kecil menunjuk pemicu. Jarak 8px dari pemicu. Muncul dengan pudar 120ms setelah jeda 400ms; hilang segera.

**Aturan:** satu kalimat pendek tanpa tautan atau tombol (kalau perlu interaksi, pakai [Popover](../Popover)). Jangan menyembunyikan informasi penting di tooltip. Tooltip tidak menggantikan label ikon: ikon tetap memiliki `aria-label`.

**Perilaku:** muncul pada hover **dan** fokus papan ketik, hilang pada `Esc` atau saat kursor pergi. `role="tooltip"` dihubungkan lewat `aria-describedby`.

**Z-index:** `ev-z-popover`.

**Yang disediakan konsumen:** teks dan elemen pemicu.

**Pemicu ⓘ (info) di halaman referensi:** tombol ikon lingkaran-i 20px (garis 2, `ev-ink-2`) di kepala kartu "Hak cuti tahunan", dengan area ketuk 44x44 (margin negatif -9px -11px agar ikon sejajar tepi kartu) dan `aria-label="Informasi hak cuti tahunan"`. Di halaman baru tombolnya ada tetapi belum membuka apa pun; isinya harus berupa Tooltip (desktop, hover dan fokus) atau [Popover](../Popover) kecil (mobile, ketuk) berisi satu sampai tiga kalimat dari teks ketentuan, maksimal 240px lebar, dengan tautan "Selengkapnya" ke halaman Ketentuan. Satu komponen pemicu ini tidak dibuat terpisah.

