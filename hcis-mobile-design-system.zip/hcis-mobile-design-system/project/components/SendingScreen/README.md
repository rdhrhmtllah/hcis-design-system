Layar penuh yang menutup halaman selama pengiriman: pengguna melihat pengajuannya "berjalan" ke atasan dan HR. Muncul di antara tombol "Kirim pengajuan" dan layar hasil ([SuccessScreen](../SuccessScreen), atau galat).

**Latar:** gradien radial berpusat di 50% / 40%: `ev-purple-600` 0%, `ev-purple-800` 46%, `ev-purple-950` 100%. Empat lingkaran garis putih 4 sampai 7% (jari-jari 120, 190, 270, 360, garis 1.5) berpusat di titik yang sama. Tiga gumpalan kabur (`filter:blur(46px)`, opasitas .4): `ev-purple-400`, `ev-purple-700`, dan `ev-gold` (opasitas .16). Lima garis tipis 2px memudar bergerak ke kanan (kecepatan 1.7 sampai 2.6 detik). Semua dekorasi bersifat `aria-hidden`.

**Jalur kirim (350x170, kiri 20, atas 252 pada layar 844):** dokumen putih 60x80 `ev-r-lg` di kiri (pita emas 24x8, tiga garis `ev-purple-edge`), jalur putus-putus (putih 18% garis penuh, putih 30% titik `1 8`) menuju simpul. Simpul berupa kotak 18px `ev-r-sm`: yang sudah dilewati terisi, yang tujuan memiliki kotak garis putih 60% lalu berubah hijau dengan centang `ev-ok-ink` saat selesai, sisanya garis putih 30%. Simpul pertama 16px putih dengan lingkar emas 35%. Label di bawah simpul 12/600, putih 80% untuk yang aktif. Jejak emas (`ev-gold`, garis 3.5, di bawahnya halo 10px opasitas .28) menggambar dirinya sepanjang jalur, di depannya komet kecil.

**Teks (rata tengah, atas 520):** judul Bricolage 26/800 putih, jarak huruf -.4px: "Mengirim pengajuan". Di bawahnya satu baris pesan 14/500 `ev-purple-150` yang bergantian tiga kali (0.45s, 1.15s, 1.85s): "Memeriksa saldo cuti…", "Menghubungi atasan langsung…", "Hampir selesai…". Lalu pil ringkasan: tinggi 34, `ev-r-lg`, putih 14% dengan garis putih 22%, 13/600 putih: "12–13 Nov · 2 hari kerja".

**Bilah kemajuan:** kiri dan kanan 85px, 96px dari dasar, tinggi 6, `ev-r-xs`, jalur putih 20%, isian `ev-gold` yang mengisi sampai penuh.

**Hasil gagal:** jalur berhenti pada simpul tempat putus. Label "Putus" (jaringan) berwarna oranye atau "Saldo kurang" (rawan) berwarna mawar muncul di simpul itu, percikan kecil tersebar, lalu layar berganti ke galat. Detail galat ada di [InlineMessage](../InlineMessage) dan `patterns.md`.

**Aksesibilitas:** `role="status"` dan `aria-live="polite"` dengan `aria-label="Mengirim pengajuan"`. Pesan bergantian dibacakan hanya yang terakhir ("Hampir selesai…"). Dengan `prefers-reduced-motion`: tanpa gumpalan, garis, komet, dan percikan; jejak langsung terisi; pesan tunggal "Mengirim pengajuan…".

**Aturan:** tidak ada tombol; tidak bisa dibatalkan setelah dimulai (pengiriman maksimal sekitar 3 detik; bila lebih dari 8 detik tampilkan [InlineMessage](../InlineMessage) "Koneksi lambat, tetap menunggu…"). Bukan pemuat umum: pakai [Skeleton](../Skeleton) untuk memuat data.

**Responsif:** mobile layar penuh. Tablet dan desktop: berubah menjadi [Dialog](../Dialog) `ev-w-dialog-m` dengan isian gradien yang sama, jalur diperkecil, tanpa lingkaran besar. *(usulan)*

**Yang disediakan konsumen:** teks ringkasan, daftar simpul berurutan (label), hasil akhir (selesai atau putus di simpul ke-n).
