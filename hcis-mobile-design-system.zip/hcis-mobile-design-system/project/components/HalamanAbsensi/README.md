**Halaman contoh (pilot)** yang dirancang dengan mengikuti [Cara menyusun halaman baru](cara-menyusun-halaman). Jenisnya berbeda dari Cuti Saya: bukan daftar pengajuan, melainkan catatan harian per minggu dengan satu koreksi di baris tertentu. Dipakai untuk menguji apakah aturan dan komponen cukup tanpa mengarang. **Seluruh data di preview adalah contoh.**

## Brief
1. **Tujuan:** melihat catatan presensi periode berjalan dan mengajukan koreksi bila ada yang tidak tercatat.
2. **Pengguna:** karyawan, ESS Personal (menu Absensi).
3. **Data utama:** rekap periode (tiga angka), shift dan presensi hari ini, daftar harian per minggu dengan status.
4. **Aksi utama:** "Ajukan koreksi" pada baris yang bermasalah (bukan aksi halaman).
5. **Keadaan:** memuat, kosong (periode baru tanpa catatan), galat, banyak data (sebulan penuh, dikelompokkan per minggu), luring.
6. **Perangkat:** mobile acuan; tablet dan desktop usulan.
7. **Hubungan:** datang dari Menu, tab Presensi, atau notifikasi "Absen pulang belum tercatat"; menuju formulir koreksi.

## Resep
| Zona | Komponen | Data | Keadaan khusus |
|---|---|---|---|
| Kepala | [PageHeader](../PageHeader) bertumpuk, pil emas "Periode berjalan" | judul, ESS · Personal | – |
| Kabar | [Banner](../Banner) nada oranye | "1 absen perlu dikoreksi, ajukan sebelum 7 Nov" dengan tombol "Lihat" | hilang bila tidak ada yang perlu dikoreksi |
| Ringkasan | tiga [StatTile](../StatTile) angka besar (hijau, oranye, mawar) | hari hadir, kali terlambat, perlu koreksi | memuat: [Skeleton](../Skeleton) |
| Isi 1 | kartu "Hari ini" bergaya InfoList bentuk B | shift, masuk, pulang, status | pulang belum tercatat: "Belum waktunya" |
| Isi 2 | [FilterChip](../FilterChip) (Semua, Perlu koreksi, Terlambat) | saringan | kosong per saringan |
| Isi 3 | daftar baris per minggu (kepala "MINGGU INI") bentuk [HistoryRow](../HistoryRow) | catatan harian | kosong, galat |
| Aksi | tombol ghost "Ajukan koreksi" di dalam baris | hanya baris "Perlu koreksi" | nonaktif setelah batas pengajuan |
| Navigasi | [BottomNav](../BottomNav), tab Presensi aktif | – | – |

## Alasan pilihan di luar tabel keputusan
- **Ubin tanggal menampilkan hari singkat (SEN, SEL…) di atas angka, bukan bulan**, karena daftar dikelompokkan per minggu dan bulan sudah jelas dari konteks. Ubin tetap 46px dengan struktur yang sama dengan HistoryRow.
- **Banner di bawah kepala** karena kabarnya harus terbaca sebelum isi dan mengarah ke tindakan; sama seperti template Detail.
- **Nada mawar untuk StatTile "perlu koreksi"** (ditambahkan ke tabel nada StatTile): angka yang bermasalah harus berwarna berbeda dari yang netral.
- **Aksi koreksi di baris, bukan di bilah dasar**, mengikuti aturan "aksi hanya untuk sebagian baris".

## Kasus yang perlu dirancang berikutnya
Banyak data (satu bulan penuh: kepala "MINGGU LALU", "2 MINGGU LALU" dan muat bertahap), kosong, galat, luring, dan versi tablet dan desktop. Desktop (usulan): dua kolom, kiri Ringkasan dan Hari ini, kanan [DataTable](../DataTable) (Tanggal, Shift, Masuk, Pulang, Status, Aksi) menggantikan daftar baris, Banner menjadi baris di atas isi.
