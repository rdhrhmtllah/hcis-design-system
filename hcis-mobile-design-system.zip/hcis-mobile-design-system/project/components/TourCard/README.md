Kartu ajakan tur terpandu di tab "Tur" pada panel Bantuan: nama tur, durasi, daftar langkah bernomor, dan satu tombol mulai. Satu kartu per halaman yang punya tur.

**Susunan:** `ev-white`, `ev-r-xl`, garis 1px `ev-purple-100`, `ev-sh-row`, padding `ev-sp-14`.
- **Kepala:** ubin ikon 44px `ev-r-lg` isian `ev-gold` dengan tepi 1px `ev-gold-edge` dan ikon jalur `ev-ok-ink` 22px; judul 15/700 dan keterangan "5 langkah · ± 1 menit" 12/500 `ev-ink-2`; di kanan chip "Tersedia" (tinggi 24, `ev-r-md`, `ev-ok-bg`, garis `ev-ok-edge`, teks `ev-ok-ink` 12/600). Bila tur belum ada, chip menjadi "Segera" dengan nada `ev-wait-*`.
- **Daftar langkah:** kolom jarak `ev-sp-2`, tiap baris tinggi minimal 30: nomor dalam lingkaran 22px (indikator langkah, satu dari sedikit tempat lingkaran dipakai) putih dengan garis 1px `ev-purple-edge`, angka 12/600 `ev-purple-800`; label 13/500 `ev-ink`. Baris masuk bergantian 50ms.
- **Tombol mulai:** tinggi 48, `ev-r-lg`, gradien 145deg `ev-purple-accent` ke `ev-purple-700`, bayangan `0 10px 18px -8px rgba(76,47,196,.7)`, ikon putar 16px, label 14/700 putih. Di halaman gradien ini hanya dipakai pada tombol ini (tombol utama lain memakai `ev-purple-600` dengan `ev-sh-btn`); jangan menyebarkannya.
- **Catatan di bawah kartu:** 12/500 `ev-ink-2`: "Tur akan menyorot tiap bagian halaman satu per satu. Kamu bisa berhenti kapan saja."

**State:** belum dimulai ("Mulai tur"), sedang berjalan ("Lanjutkan tur"), selesai (label "Ulangi tur", langkah semua bercentang `ev-ok-ink`), tidak tersedia (kartu tanpa tombol, chip "Segera").

**Perilaku:** ketuk tombol menutup panel dan memulai [Coachmark](../Coachmark) langkah 1. Tur bisa dihentikan kapan saja dan posisinya diingat sehingga tombol menjadi "Lanjutkan tur".

**Responsif:** mobile satu kolom penuh lebar panel. Tablet dan desktop: lebar kartu tetap 362 di dalam panel `ev-w-panel`. *(usulan)*

**Yang disediakan konsumen:** nama tur, daftar langkah, status ketersediaan, handler mulai.
