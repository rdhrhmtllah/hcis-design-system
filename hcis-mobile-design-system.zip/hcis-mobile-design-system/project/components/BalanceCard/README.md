Kartu hero saldo cuti di bagian atas halaman, menumpang pada header ungu.

**Susunan:** label "Hak cuti tahunan" dan ikon info; angka saldo `display-xl` (Bricolage 800, `ev-purple-800`) dengan satuan "hari"; keterangan "Tersedia untuk diajukan"; ubin "Hutang cuti" `ev-purple-50` di kanan; batang progres `ev-purple-600` dengan label "Terpakai" dan "Jatah"; tombol utama (`Button`) di bagian bawah kartu.

**State:** normal, ada hutang cuti (angka hutang di ubin bukan nol; teks ubin memakai `ev-no-ink`), memuat (`Skeleton`), galat (belum dirancang).

**Yang disediakan konsumen:** saldo, hutang, terpakai, jatah, dan aksi pengajuan.

**Jangan:** menaruh dua angka besar di satu kartu atau mengecilkan angka saldo di bawah `display-xl`.

**Responsif:** Mobile: penuh lebar. Tablet: dua kartu per baris. Desktop: berjajar dengan [StatCard](../StatCard) di kisi 12 kolom, angka tetap 32/800. *(usulan)*
