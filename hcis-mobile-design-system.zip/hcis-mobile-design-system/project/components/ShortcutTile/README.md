Pintasan bergambar ke tiga sampai empat tujuan utama sebuah halaman (di Cuti Saya: Riwayat, Jenis cuti, Ketentuan). Dipasang sebaris di bawah kartu saldo dan membuka halaman penuh atau panel.

**Susunan:** satu tombol per pintasan, lebar 92px, kolom rata tengah, jarak ubin ke label `ev-sp-6`.
- **Ubin:** 52x52, `ev-r-lg` (bukan lingkaran), isian warna nada, ikon 26px garis 2 berwarna tinta nada, tepi bawah 3px berwarna tepi nada (`box-shadow:0 3px 0`) ditambah kilap tipis `inset 0 1px 0 rgba(255,255,255,.7)`. Ini bahasa ubin 3D yang sama dengan ubin ikon di Menu.
- **Label:** 12/600 `ev-ink`, satu baris, tanpa elipsis (maksimal dua kata).

**Nada:** ungu (Riwayat), hijau (Jenis cuti), biru (Ketentuan). Satu nada untuk satu tujuan, tetap di seluruh aplikasi; jangan memberi dua pintasan di halaman yang sama satu nada.

**Pembungkus:** `nav` dengan `aria-label="Pintasan cuti"`, `display:flex; justify-content:space-around`, margin atas `ev-sp-14`, samping `ev-sp-14`. Bila lebih dari empat pintasan, ganti dengan [StatCard](../StatCard) atau menu daftar.

**State:** normal, ditekan (ubin turun 3px, tepi bawah menipis, `motion.md` "press"), fokus (garis 2px `ev-purple-600`, jarak 2px), nonaktif (opasitas .5, hanya bila fitur tidak tersedia untuk peran pengguna; lebih baik disembunyikan). Pintasan yang membuka panel memakai `aria-haspopup="dialog"`.

**Responsif:** mobile tiga sampai empat sejajar rata. Tablet: tetap sebaris, jarak lebih longgar. Desktop: ubin diperbesar ke 56 dan label di samping (baris horizontal, tombol 160px) atau dipindah ke [SideNav](../SideNav) bila tujuannya navigasi tetap. *(usulan)*

**Yang disediakan konsumen:** label, nada, ikon, handler.
