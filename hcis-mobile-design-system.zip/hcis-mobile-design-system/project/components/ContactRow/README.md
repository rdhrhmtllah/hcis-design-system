Baris kontak PIC (penanggung jawab) per modul. Ketuk untuk membuka tiga jalan hubungi: Chat, telepon ekstensi, dan Email. Dipakai di tab "PIC Modul" pada panel Bantuan. Berupa akordeon satu-buka-satu; bentuk dasarnya mengikuti [Accordion](../Accordion).

**Tertutup:** `ev-white`, `ev-r-xl`, `ev-sh-row`, tinggi minimal 60, padding 8 / 14 / 8 / 16. Ubin kode modul 40px `ev-r-md` dengan garis 1px dan kode 12/600 (ESS, TPM, LMS, DMS, VMS); nama modul 14/600; "PIC: Rina Wulandari" 12/500 `ev-ink-2`; panah bawah 18px `ev-purple-800` di kanan.

**Warna modul (tetap, bukan pilihan):** ESS ungu (`ev-purple-100`), TPM hijau (`ev-ok-bg`), LMS biru (`ev-info-bg`), DMS oranye (`ev-wait-bg`), VMS mawar (`ev-no-bg`); tepi dan tinta ikut keluarganya.

**Terbuka:** latar menjadi `ev-tint`, panah berputar 180 derajat, di bawah baris muncul (rata dengan teks, kiri 68px): peran dan jam kerja "HR Operasional · Sen–Jum 08.00–17.00" 12/500, lalu tiga tombol sama lebar (jarak `ev-sp-8`, tinggi minimal 56, `ev-r-lg`, garis 1px tepi modul, ikon 18px di atas label 12/600 berwarna tinta modul): **Chat**, **Ext. 1201**, **Email**. Isi muncul dengan `fx-reveal` (lihat `motion.md`).

**Aturan:** hanya satu baris terbuka; membuka yang lain menutup yang sebelumnya. `aria-expanded` pada tombol kepala; tiap tombol aksi punya `aria-label` ("Chat Rina Wulandari", "Telepon …", "Email …"). Tombol telepon memakai tautan `tel:` bila di perangkat seluler, di desktop menyalin ekstensi dan menampilkan [Toast](../Toast) "Ekstensi disalin".

**State:** tertutup, terbuka, ditekan (`ev-tint`), fokus (garis 2px `ev-purple-600`).

**Responsif:** mobile satu kolom. Tablet dan desktop: panel `ev-w-panel`, atau dua kolom kartu bila halaman penuh. Tombol tetap tiga sejajar. *(usulan)*

**Yang disediakan konsumen:** kode, nama modul, nama PIC, peran, jam kerja, ekstensi, alamat email.
