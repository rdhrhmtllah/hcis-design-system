Layar hasil setelah pengajuan terkirim: ilustrasi perayaan, judul, satu kalimat tindak lanjut, [ReceiptCard](../ReceiptCard), lalu [ActionBar](../ActionBar) dengan "Ajukan lagi" dan "Lihat pengajuan saya". Pola yang sama dipakai untuk hasil sukses lain (penilaian terkirim, koreksi absen terkirim) dengan isi berbeda.

**Susunan:** kolom rata tengah, padding 28 / 20 / 24, dapat digulir; ActionBar menempel di dasar.
1. **Panggung ilustrasi:** 350x170, putih, `ev-r-3xl`, `ev-sh-card`. Di atasnya halo emas (radial 38% emas di 62% / 95%), dokumen putih 88x112 `ev-r-lg` dengan garis 2px `ev-purple-100` (pita emas 30x10, empat garis `ev-purple-150`), cakram sukses 56px bulat (`ev-r-full`) dengan gradien 150deg `ev-purple-500` ke `ev-purple-800`, cincin putih 4px, centang emas 30px garis 3.2; cincin denyut 3px `ev-purple-400`. Empat kerlip empat sudut (16, 12, 16, 12px) emas dan ungu berkelip bergantian. Konfeti 26 kepingan jatuh sekali dari cakram.
2. **Judul** Bricolage 26/800, jarak huruf -.4px: kalimat selesai dengan tanda seru ("Pengajuan terkirim!"). Jarak atas 26.
3. **Kalimat tindak lanjut** 14/500 `ev-ink-2`, dua baris maksimal: apa yang terjadi sekarang dan kapan pengguna diberi tahu. Contoh: "Atasan langsung kamu sudah menerima pengajuan ini. Kamu akan dapat notifikasi saat ada keputusan."
4. **ReceiptCard** dengan jarak atas 22.
5. **ActionBar** (isi 3).

**Urutan animasi:** panggung 0.4s, cakram 0.75s, cincin 0.85s, judul 0.8s, kalimat 0.88s, kartu 0.98s, bilah naik terakhir (`fx-up`, lihat `motion.md`). Dengan `prefers-reduced-motion`: semuanya langsung tampil tanpa konfeti dan denyut.

**Varian galat:** bentuknya sama (panggung ilustrasi + judul + kalimat + aksi) tetapi `role="alert"` dan ilustrasi berganti menurut sebab: jaringan putus (cakram oranye `ev-wait-dot` dengan gelombang wifi bergaris silang), server sibuk (tolok setengah lingkaran dengan jarum), konflik tanggal (lima hari berurutan dengan hari bentrok mawar). Tombol utama menjadi "Coba lagi" dan sekunder "Simpan sebagai draf". Teks galat mengikuti pola di `patterns.md`: apa yang terjadi, apa yang aman (data tidak hilang), apa yang bisa dilakukan.

**Aturan:** satu layar sukses per alur; jangan menumpuk sheet di atasnya. Fokus ke judul (`tabindex="-1"`) agar pembaca layar langsung membaca hasil. Judul tidak memakai emoji.

**State:** masuk (animasi), tampil, keluar (`sx-exit`: seluruh isi memudar 160ms ke kiri saat berpindah ke daftar).

**Responsif:** mobile seperti di atas. Tablet dan desktop: isi dipusatkan di kolom `ev-w-form` dalam panel; ActionBar menjadi baris tombol rata kanan di bawah kartu (bukan menempel dasar). *(usulan)*

**Yang disediakan konsumen:** judul, kalimat tindak lanjut, data ReceiptCard, handler dua aksi.
