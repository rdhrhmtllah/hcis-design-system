Panel yang naik dari bawah untuk memilih sesuatu tanpa meninggalkan halaman. Di halaman referensi dipakai pada "Jenis cuti khusus". Untuk konfirmasi aksi berbahaya pakai [ConfirmSheet](../ConfirmSheet), yang punya susunan tetap sendiri.

**Susunan:** pegangan tarik 40x4 `ev-purple-150` (jarak atas `ev-sp-10`); kepala: judul Bricolage 20/700 dengan keterangan satu baris 13/500 `ev-ink-2` di kiri, tombol tutup di kanan (area 44px, ubin 34px `ev-r-lg` `ev-purple-50` dengan silang `ev-purple-800` 18px); isi yang bisa digulir dengan padding 0 / 14 / 22; subjudul kelompok 12/600 `ev-ink-2` bila perlu.

**Baris pilihan:** tinggi minimal 62, `ev-r-lg`, garis 2px, padding 8 / 12, jarak antar baris `ev-sp-6`. Kiri: label 14/700 dan keterangan 12/500. Tengah-kanan: pil nilai (tinggi 26, `ev-r-md`, 12/600). Kanan: kotak centang 22px `ev-r-md`. Terpilih: isian `ev-purple-50`, garis `ev-purple-600`, kotak terisi `ev-purple-600` dengan centang putih. Tidak terpilih: isian putih, garis `ev-purple-100`, kotak garis `ev-purple-150`.

**Bentuk:** sudut atas `ev-r-3xl`, isian `ev-white`, bayangan `ev-sh-sheet`, tinggi maksimal 80% (92% untuk ConfirmSheet), di atas scrim `rgba(26,21,53,.55)`. Baris masuk bergantian dari bawah (`fx-up`).

**Gesture:** tarik ke bawah lebih dari 110px (atau lepas cepat) menutup; ketuk scrim menutup; tombol tutup selalu ada. Memilih satu baris langsung menutup sheet bila pilihan tunggal; untuk pilihan ganda tampilkan tombol "Selesai" di dasar.

**State:** masuk, tampil, keluar; baris normal, ditekan, terpilih. Sheet tidak boleh menumpuk di atas sheet lain.

**Aksesibilitas:** `role="dialog"`, `aria-modal`, `aria-label` judul; fokus masuk ke sheet saat terbuka dan kembali ke pemicu saat tutup; baris `aria-pressed`.

**Responsif:** mobile menempel bawah. Tablet dan desktop menjadi [Popover](../Popover) atau [Dialog](../Dialog) `ev-w-dialog-s`, isi sama. *(usulan)*

**Yang disediakan konsumen:** judul, keterangan, daftar pilihan (label, keterangan, nilai), pilihan terpilih, handler.
