Sheet konfirmasi untuk aksi yang tidak bisa dibatalkan atau mengubah data penting. Di halaman referensi dipakai pada "Batalkan pengajuan ini?". Dasarnya [Sheet](../Sheet), tetapi isinya sudah ditetapkan di sini supaya setiap konfirmasi destruktif terlihat dan terasa sama.

**Susunan (dari atas):**
1. Pegangan tarik 40x4, `ev-purple-150`.
2. Cakram ikon 56px bulat penuh (`ev-r-full`): gradien 145deg `ev-no-soft` ke `ev-no-dot`, ikon silang putih 26px, tepi dalam putih 40% di atas. Dua cincin `ev-no-ring` berdenyut di belakangnya (animasi sekali saat sheet muncul, lihat `motion.md`).
3. Judul berupa pertanyaan, `title-m` Bricolage 22/700, rata tengah: "Batalkan pengajuan ini?"
4. Satu kalimat akibat utama, 14/500 `ev-ink-2`, rata tengah: "Proses approval akan dihentikan seketika."
5. **Kartu objek**: `ev-tint`, garis 1.5px `ev-purple-100`, `ev-r-xl`, padding 12x14. Kode (12/600 `ev-ink-2`), rentang tanggal (Bricolage 16/700), meta (13/500), dan [StatusChip](../StatusChip) di kanan.
6. Label "SETELAH DIBATALKAN" (12/600, huruf kapital, jarak huruf .06em, `ev-ink-3`).
7. **Tiga baris dampak**, masing-masing ubin 36px `ev-r-md` + judul 14/700 + keterangan 13/500: hijau (`ev-ok-bg`, uang atau saldo kembali), mawar (`ev-no-bg`, yang berhenti), ungu (`ev-purple-100`, yang masih bisa dilakukan). Setiap baris masuk bergantian 60ms.
8. **Tombol berbahaya**: tinggi 54, `ev-r-xl`, isian `ev-no-dot`, tepi bawah 4px `ev-no-deep`, ikon tempat sampah 18px, label "Ya, batalkan pengajuan" 15/700 putih.
9. **Tombol batal**: tinggi 50, `ev-r-lg`, `ev-purple-50`, teks `ev-purple-800`, label "Tidak jadi".

**Bentuk:** sudut atas `ev-r-3xl` (di halaman 26px), `ev-sh-sheet`, padding 10 / 18 / 20, `role="alertdialog"` dan `aria-modal`. Tinggi maksimal 92%, isi bisa digulir. Scrim `rgba(26,21,53,.55)`.

**Aturan isi:** judul selalu pertanyaan dengan kata kerja aksi; tombol utama mengulang kata kerja yang sama ("Ya, batalkan pengajuan"), bukan "OK". Tombol batal memakai kalimat penolakan ("Tidak jadi"), bukan "Batal" supaya tidak ambigu dengan "Batalkan". Tiga baris dampak maksimal; urutan: apa yang kembali, apa yang berhenti, apa yang masih mungkin.

**Gesture:** tarik ke bawah >110px menutup; ketuk scrim menutup; tombol "Tidak jadi" selalu ada. Fokus pertama jatuh ke "Tidak jadi" (aksi aman), bukan ke tombol berbahaya.

**State:** masuk, tampil, mengirim (tombol berbahaya berganti "Membatalkan…", nonaktif), galat (lihat [InlineMessage](../InlineMessage) di atas tombol), keluar.

**Responsif:** mobile menempel bawah. Tablet dan desktop berubah menjadi [Dialog](../Dialog) ukuran `ev-w-dialog-s` di tengah, isinya sama, dua tombol berdampingan (batal di kiri). *(usulan)*

**Yang disediakan konsumen:** judul, kalimat akibat, objek (kode, rentang, meta, status), maksimal tiga dampak (ikon, nada, judul, keterangan), handler konfirmasi dan batal.

**Jangan:** memakai merah ini untuk aksi yang bisa diurungkan, menambah kolom isian di sheet ini, atau menaruh tombol berbahaya di atas tombol batal tanpa jarak 12px.
