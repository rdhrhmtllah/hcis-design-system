Layar Menu: pemilih modul dan layanan HCIS. Disalin dari halaman referensi; terbuka dari tombol Menu di BottomNav.

**Struktur (atas ke bawah)**
1. **Kepala:** judul "Menu" (Bricolage `display-l` 32/800 putih), keterangan "Semua modul dan layanan HCIS" (`caption`, `ev-purple-150`), dan tombol tutup berupa ubin kaca 34px `ev-r-md` dalam area ketuk 44px. Latar gradasi `ev-purple-900` ke `ev-purple-800` dengan cincin tipis dan kilau emas.
2. **Cari:** kolom tinggi 48px `ev-r-xl`, garis 1,5px putih 22%, latar putih 12%, placeholder "Cari menu atau layanan", kilau emas di kanan.
3. **Sering dikunjungi:** bintang emas dan judul 12/600, lalu deretan ubin 86px yang bisa digulir mendatar. Ubin: `ev-r-xl`, ikon 38px `ev-r-md` dengan tepi bawah 3px.
4. **Chip modul:** ESS, TPM, LMS, DMS, VMS. Chip `ev-r-xl` tinggi 36px 13/700, kaca; yang aktif `ev-gold` dengan teks `ev-gold-ink`.
5. **Daftar per kelompok:** judul kelompok (12/600, putih 85%), lalu kisi 2 kolom baris minimal 58px: ikon 40px, label 14/600, keterangan 12/500.

**Aktif:** ubin dan baris putih penuh, teks `ev-ink`, ubin ikon `ev-purple-600` dengan tepi `ev-purple-800` dan ikon putih; modul yang sedang dibuka diberi keterangan "Sedang dibuka".

**Gesture:** geser bawah menutup; geser kiri atau kanan pindah modul. Tombol tutup tetap tersedia.

**Tablet dan desktop (usulan):** menjadi popover putih `ev-r-2xl` (`ev-sh-pop`) yang berlabuh di tombol Modul pada SideNav. Isi sama, baris `ev-purple-50` dengan garis `ev-purple-edge`, aktif putih dengan garis 2px `ev-purple-600`. `Esc` menutup.

**State baris:** normal, hover (putih 16%), fokus (cincin `ev-gold` 2px), aktif, ditekan (turun 1px), terkunci (pudar 55%).

**Z-index:** `ev-z-nav`.

**Yang disediakan konsumen:** daftar modul, kelompok, modul aktif, favorit.
