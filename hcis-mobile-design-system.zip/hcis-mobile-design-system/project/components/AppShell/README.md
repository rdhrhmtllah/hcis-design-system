Kerangka halaman: menentukan di mana navigasi, header, dan isi berada pada tiap ukuran layar. Semua halaman memakai kerangka ini; halaman tidak membuat navigasinya sendiri.

**Usulan: hanya susunan mobile yang berasal dari halaman referensi.** Tablet dan desktop adalah proposal.

**Susunan**
- **Mobile (sampai 599px):** header di atas, isi satu kolom bergulir, [BottomNav](../BottomNav) melayang di bawah.
- **Tablet (600 sampai 1023px):** [SideNav](../SideNav) bentuk rel 72px di kiri, isi di sebelahnya. Detail muncul sebagai panel di kanan.
- **Desktop (1024px ke atas):** [SideNav](../SideNav) bentuk sidebar 248px, header halaman, isi dengan lebar maksimum `ev-w-content`. Detail memakai tampilan terbagi.

**Area isi:** margin dan celah mengikuti tabel di halaman Layout. Latar `ev-bg`, kartu `ev-white`.

**Yang disediakan konsumen:** judul halaman, tujuan aktif, isi, dan (opsional) panel detail.

**Jangan:** menaruh dua navigasi utama sekaligus, atau menaruh BottomNav di layar tablet ke atas.
