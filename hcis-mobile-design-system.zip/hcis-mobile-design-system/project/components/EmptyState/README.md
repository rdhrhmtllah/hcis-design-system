Tampilan saat daftar kosong. Ada tiga: pengajuan aktif, riwayat, dan notifikasi.

**Susunan:** ilustrasi sederhana yang melayang pelan (kalender dengan tanda tambah, jam, lonceng dengan centang), judul `heading-s`, satu kalimat penjelasan `body`, dan satu aksi bila ada langkah yang masuk akal ("Ajukan cuti", "Lihat riwayat"). Kartu `ev-white` bersudut `ev-r-2xl`.

**Isi pesan:** ramah dan menyebut langkah berikutnya, bukan hanya keadaan. "Belum ada pengajuan aktif. Ajukan cuti kapan saja dari tombol di atas."

**State:** kosong biasa, kosong karena filter ("Belum ada yang disetujui"), kosong karena offline (belum dirancang).

**Yang disediakan konsumen:** jenis, judul, penjelasan, dan aksi opsional.

**Jangan:** menampilkan keadaan kosong saat data masih memuat (pakai `Skeleton`), atau menaruh dua aksi.

**Responsif:** Sama di semua ukuran; di desktop ilustrasi dan teks dibatasi lebar 360px dan diletakkan di tengah wadah.
