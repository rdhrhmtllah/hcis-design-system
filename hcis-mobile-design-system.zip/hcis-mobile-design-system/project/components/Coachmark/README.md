Petunjuk tur yang menyorot satu bagian halaman sambil menjelaskannya. Dipanggil oleh tombol "Mulai tur" di [TourCard](../TourCard): satu coachmark per langkah, urut. **Seluruh komponen ini usulan.** Halaman referensi baru memiliki tombol mulai tur dan daftar lima langkahnya, belum menggambar sorotannya; bentuk di bawah disusun hanya dari token dan pola yang sudah ada (kartu [Popover](../Popover), nomor langkah TourCard, scrim [Sheet](../Sheet)).

**Susunan:**
1. **Scrim** `rgba(26,21,53,.55)` menutup seluruh layar kecuali target.
2. **Sorotan:** lubang pada scrim seukuran target ditambah 6px di setiap sisi, `ev-r-xl`, cincin 2px `ev-gold` (satu-satunya tempat emas dipakai sebagai garis).
3. **Kartu petunjuk:** `ev-white`, `ev-r-xl`, `ev-sh-pop`, padding `ev-sp-14`, lebar maksimal 300, jarak 12px dari sorotan, ditaruh di atas atau di bawah target menurut ruang. Ekor 12px berbentuk kotak diputar 45 derajat (`ev-r-xs`) menunjuk target.
   - Baris atas: nomor langkah dalam lingkaran 22px seperti TourCard dan teks "2 dari 5" 12/600 `ev-purple-accent`.
   - Judul 15/700 `ev-ink` dan satu atau dua kalimat 13/500 `ev-ink-2`.
   - Baris aksi: "Lewati tur" teks 13/600 `ev-ink-2` (area 44px) di kiri; di kanan "Lanjut" (tinggi 36, `ev-r-lg`, `ev-purple-600`, putih 13/700). Langkah terakhir menjadi "Selesai". Langkah kedua dan seterusnya menambah "Kembali" sebagai teks `ev-purple-800` di sebelah kiri "Lanjut".

**Isi lima langkah halaman Cuti Saya:** "Cek saldo cuti kamu", "Ajukan cuti baru", "Pantau pengajuan aktif", "Buka menu semua modul", "Cari bantuan kapan saja".

**Gesture dan papan ketik:** ketuk di luar kartu tidak menutup tur (cegah keluar tidak sengaja); tombol "Lewati tur" selalu ada; panah kanan atau Enter = Lanjut, panah kiri = Kembali, Esc = Lewati. Gulir halaman otomatis agar target terlihat sebelum kartu muncul.

**Aksesibilitas:** `role="dialog"` dengan `aria-label="Tur, langkah 2 dari 5"`; fokus masuk ke kartu dan dijebak di dalamnya; target tetap `aria-hidden` pada scrim tetapi sorotan tidak menghalangi pembaca layar membaca target setelah tur selesai. Dengan `prefers-reduced-motion`: sorotan berpindah tanpa luncuran.

**Animasi:** sorotan meluncur ke target berikut (`ev-t-mid`, `ev-ease-standard`), kartu memudar dan naik 8px (`motion.md`).

**State:** langkah pertama, tengah, terakhir; target tidak ditemukan (lewati langkah, jangan macet).

**Responsif:** mobile seperti di atas. Tablet dan desktop: kartu 320 dan boleh di sisi target (kiri atau kanan) bila ruang atas-bawah kurang. *(usulan)*

**Yang disediakan konsumen:** daftar langkah (target, judul, isi), handler lewati dan selesai.
