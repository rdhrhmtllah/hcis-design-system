Baris riwayat pengajuan yang sudah diputuskan, dikelompokkan per bulan. Bisa dibuka untuk melihat alur, kode, waktu, dan pemutus tanpa pindah halaman. Dipakai di halaman Riwayat. Berbeda dari [RequestCard](../RequestCard) (pengajuan yang masih berjalan, dengan jalur kemajuan), HistoryRow untuk yang sudah selesai.

**Kepala bagian bulan:** 12/600, jarak huruf .5px, `ev-ink-2`, padding 12 / 6 / 6: "OKTOBER 2026". Masuk bergantian saat daftar muncul.

**Tertutup:** kartu `ev-white`, `ev-r-2xl`, `ev-sh-card`, jarak antar kartu `ev-sp-10`, seluruh kepala adalah satu tombol (tinggi minimal 76, padding 12 / 12 / 12 / 14).
- **Ubin tanggal** 46x54, `ev-r-lg`, `ev-purple-50` dengan garis 1px `ev-purple-100`: bulan 12/600 huruf kapital `ev-purple-600` di atas, hari Bricolage 20/700 di bawah. Menunjukkan tanggal mulai cuti.
- **Tengah:** rentang Bricolage 16/700 ("12–16 Oktober"), di bawahnya meta 13/500 `ev-ink-2` ("5 hari kerja · Cuti tahunan").
- **Kanan:** [StatusChip](../StatusChip) (disetujui, ditolak, dibatalkan) dan panah bawah 20px `ev-purple-800` yang berputar 180 derajat saat terbuka.

**Terbuka:** isi diturunkan dengan `fx-reveal` di bawah garis 1px `ev-purple-50`, padding 2 / 14 / 14.
1. "Alur persetujuan" 12/600 `ev-ink-2` lalu stepper ringkas (sama dengan [ReceiptCard](../ReceiptCard)).
2. Kisi dua kolom `auto 1fr` (jarak 6 / 14, 13px): Kode, Diputuskan, Oleh. Label 600 `ev-ink-2`, nilai 800 `ev-ink`.
3. Bila ada catatan dari pemutus: kotak `ev-r-lg` padding 10 / 12, 13/500, warna sesuai keluarga status (hijau untuk disetujui, mawar untuk ditolak); isi catatan apa adanya.
4. Tombol "Lihat detail lengkap" (46, `ev-r-lg`, `ev-purple-50`, garis 1.5px `ev-purple-150`, `ev-purple-800` 14/700, panah 16px).

**Perilaku:** hanya satu baris terbuka; membuka yang lain menutup sebelumnya. Saring dengan [FilterChip](../FilterChip) di atas daftar (Semua, Disetujui, Ditolak, Dibatalkan). Daftar kosong memakai [EmptyState](../EmptyState) dengan teks per saringan ("Belum ada yang ditolak").

**State:** tertutup, terbuka, ditekan (`ev-tint`), memuat ([Skeleton](../Skeleton) tinggi 72), kosong, galat.

**Aksesibilitas:** `aria-expanded` pada tombol kepala; kartu `article`. Panah dan ubin tanggal `aria-hidden`; teks tombol dibaca "12–16 Oktober, 5 hari kerja, Disetujui".

**Responsif:** mobile satu kolom. Tablet dan desktop: [DataTable](../DataTable) menggantikan daftar (kolom Tanggal, Jenis, Durasi, Status, Diputuskan), baris yang diketuk membuka panel detail di sisi kanan, bukan akordeon. *(usulan)*

**Yang disediakan konsumen:** tanggal, rentang, meta, status, data alur, kode, waktu dan pemutus, catatan, handler detail.
