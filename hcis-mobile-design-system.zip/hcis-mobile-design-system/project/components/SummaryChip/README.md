Pill ringkasan di header: menunjukkan jumlah pengajuan per status sekaligus menjadi filter daftar di bawahnya.

**Aturan**
- Maksimal 3 pill. Status berjumlah 0 disembunyikan.
- Lebih dari 3 jenis status: tampilkan 2 teratas menurut prioritas ditambah pill "+N" yang menggulung ke daftar.
- Tidak ada data: satu pill netral "Tidak ada pengajuan aktif".
- Mengetuk pill memfilter daftar; mengetuk lagi mengembalikan semua. Judul daftar berubah menjadi nama status dan jumlah (contoh "Menunggu · 3"); tanpa filter hanya "Pengajuan aktif".
- Tinggi tampilan 28px, tetapi area ketuk diperluas ke 44px (elemen semu, bukan padding).

**State:** normal (isian putih transparan 14% di atas ungu tua, garis putih 22%), aktif (isian putih, teks `ev-purple-800`), overflow "+N", kosong.

**Yang disediakan konsumen:** daftar status berurutan prioritas dengan jumlahnya, dan handler filter.

**Jangan:** memakai kata istilah proses ("Diproses"), menaruh lebih dari 3 pill, atau memakai pill ini di atas latar terang (ia dirancang untuk header ungu tua).

**Responsif:** Mobile: di header Cuti Saya, maksimal tiga. Tablet dan desktop: berpindah ke baris di atas daftar sebagai [FilterChip](../FilterChip) atau [Tabs](../Tabs), dan hitungan tampak semua tanpa "+N". *(usulan)*
