Kartu bukti berbentuk tiket yang merangkum satu pengajuan: kode, status, rentang, jenis, durasi, saldo, dan alur persetujuan. Di halaman dipakai pada layar hasil ([SuccessScreen](../SuccessScreen)). Pakai komponen ini, bukan [RequestCard](../RequestCard), bila tujuannya "bukti yang bisa dilihat ulang", bukan "baris dalam daftar".

**Bagian atas:** padding 14 / 16 / 12. Baris kode (12/600, `letter-spacing:.4px`, `ev-ink-2`) di kiri dan [StatusChip](../StatusChip) di kanan (tinggi 24, `ev-r-md`, titik 7px persegi `ev-r-xs`). Di bawahnya rentang tanggal Bricolage 22/700.

**Sobekan tiket:** pemisah setinggi 20px. Dua kotak 20px `ev-r-md` berisian `ev-bg` terpasang setengah ke luar di kiri dan kanan (-10px) agar tampak seperti takik; di antaranya garis putus-putus 2px `ev-purple-150` dengan margin 16px kiri dan kanan. Takik harus memakai warna latar halaman (`ev-bg`), bukan putih; jangan taruh kartu ini di latar selain `ev-bg` tanpa mengganti warna takik.

**Bagian bawah:** padding 0 / 16 / 16.
- Kisi tiga kolom (`1.1fr 1fr 1fr`, jarak `ev-sp-8`): label 12/500 `ev-ink-2` di atas, nilai 13/700 `ev-ink` di bawah. Isi: Jenis, Durasi, Saldo.
- Garis putus 1.5px `ev-purple-100` di atas "Alur persetujuan" (12/600 `ev-ink-2`) dengan jarak 14 / 12.
- Alur: tiga kolom sama lebar. Tiap kolom: batang 4px kiri dan kanan di kiri-kanan simpul 24px `ev-r-md` bernomor 12/600; di bawahnya peran 13/700 dan keterangan 12/500 `ev-ink-2`. Simpul selesai `ev-purple-600` dengan centang putih, simpul berjalan garis 2px `ev-purple-600`, simpul berikutnya garis `ev-purple-150`. Batang yang sudah dilalui `ev-purple-600`, sisanya `ev-purple-100`. Ini adalah [ApprovalStepper](../ApprovalStepper) versi ringkas; untuk detail per tahap dengan waktu pakai ApprovalStepper penuh.

**Bayangan:** `0 14px 28px -16px rgba(45,23,120,.45), 0 2px 5px rgba(45,23,120,.06)`; bila ingin satu token, pakai `ev-sh-card`.

**Aturan:** lebar mengisi wadah (maksimal 350). Nilai panjang (jenis cuti) memotong dengan elipsis dua baris, bukan mendorong kolom. Status di sini selalu sama dengan status resmi; jangan menulis status buatan.

**State:** baru dikirim ("Menunggu"), disetujui, ditolak, dibatalkan (ikuti [StatusChip](../StatusChip) dan nada empat keluarga status). Saat tampil pertama, kartu naik dari bawah 24px dengan fade, tertunda 0.98s di layar hasil (`motion.md`).

**Aksesibilitas:** dua kotak takik dan garis putus `aria-hidden`. Bila kartu dibaca, urutan: kode, status, rentang, jenis, durasi, saldo, alur.

**Responsif:** lebar tetap 350 di semua perangkat; di tablet dan desktop kartu dipusatkan di panel hasil `ev-w-form`. *(usulan)*

**Yang disediakan konsumen:** kode, status, rentang, jenis, durasi, saldo, daftar tahap (peran, status, keterangan).
