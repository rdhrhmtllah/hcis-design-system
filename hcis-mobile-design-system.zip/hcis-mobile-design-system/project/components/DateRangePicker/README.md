Kalender pemilih rentang tanggal. Disalin dari langkah "Tanggal cuti" pada halaman Ajukan cuti.

**Dalam kartu bernomor:** kartu putih `ev-r-2xl` dengan lencana nomor 24px `ev-r-md` `ev-purple-600`, judul "Tanggal cuti" (`title-s` 15/700), dan petunjuk di kanan ("Pilih tanggal mulai", lalu "Pilih tanggal selesai").

**Kepala bulan:** nama bulan Bricolage 16/700 di tengah, panah kiri dan kanan 44px (`ev-purple-800`; pudar `ev-ink-3` bila tidak bisa mundur). **Baris hari:** Sen sampai Min, 12/600 `ev-ink-2`.

**Sel (44px)**
- **Terpilih (mulai dan selesai):** lingkaran `ev-purple-600`, angka putih 800.
- **Di antara:** pita `ev-purple-200` penuh tinggi sel; di ujung mulai dan selesai pita hanya setengah sel ke arah rentang.
- **Hari ini:** cincin 1,5px `ev-purple-400`, tanpa isian.
- **Sudah lewat dan akhir pekan:** angka `ev-ink-3`, tidak bisa dipilih.
- **Hari libur:** titik 4px `ev-no-ink` di bawah angka; dibaca pembaca layar ("libur Hari Raya").
- **Biasa:** angka 600 `ev-ink`.

**Perilaku:** ketuk pertama = mulai, ketuk kedua = selesai; bila lebih awal dari mulai, mulai diganti. Jenis cuti bertetapan (misalnya melahirkan) mengisi selesai otomatis. Rentang yang seluruhnya hari libur menampilkan "Rentang hanya hari libur" dan tidak bisa dilanjutkan. Papan ketik: panah memindah sel, Enter memilih, `PageUp` dan `PageDown` ganti bulan.

**Bilah ringkasan** di kaki sheet: judul ("Pilih tanggal cuti", lalu "4 hari kerja"), keterangan, kapsul jenis cuti, dan tombol utama [Button](../Button) yang nonaktif sampai rentang valid.

**Tablet dan desktop (usulan):** dua bulan berdampingan di dalam [Dialog](../Dialog) atau [Popover](../Popover); sel tetap 44px.

**Yang disediakan konsumen:** rentang, hari libur, hari tak tersedia, sisa cuti, handler.
