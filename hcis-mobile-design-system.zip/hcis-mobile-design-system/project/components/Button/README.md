Tombol utama HCIS Mobile: blok 3D berwarna ungu dengan tepi bawah tebal. Dipakai untuk satu aksi utama per layar.

**Varian**
- **Utama (CTA beranda):** tinggi 56px, isian `ev-purple-600`, bayangan `ev-sh-btn`, ikon kotak emas di kiri, label `heading-s` putih, panah di kanan.
- **Utama (sheet dan Detail):** tinggi 54px, label 15px bobot 700, putih di atas `ev-purple-600`.
- **Berbahaya (kontur):** isian `ev-white`, garis 1,5px mawar muda, teks `ev-no-ink`. Dipakai untuk "Batalkan", selalu di sisi kiri tombol utama.
- **Selesai:** isian `ev-ok-bg`, teks `ev-ok-ink`, tanpa bayangan, label menyatakan hasil ("Sudah diingatkan"). Tidak bisa diketuk.

**State yang harus ada:** normal, ditekan (tombol turun, tepi bawah menipis), nonaktif (`aria-disabled`, tampil pudar), memuat (label diganti kata kerja berjalan, misalnya "Mengirim…"), selesai.

**Yang disediakan konsumen:** label (kata kerja pendek), handler, dan keadaan. Satu tombol utama per layar; jangan menaruh dua tombol ungu bersebelahan.

**Jangan:** memakai emas sebagai isian tombol utama, mengubah radius, atau memakai tombol 3D untuk aksi sekunder (pakai kontur).

**Responsif:** Mobile: tombol penuh lebar. Tablet dan desktop: lebar mengikuti isi (minimal 120px), tinggi 48px, ditaruh di kanan kaki dialog atau formulir; tombol tidak pernah lebih lebar dari `ev-w-form`. Hover: warna naik satu tingkat tanpa mengubah ukuran; fokus: cincin 2px `ev-purple-600`. *(tablet dan desktop adalah usulan)*
