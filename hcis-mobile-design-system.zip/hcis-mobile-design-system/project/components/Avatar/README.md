Inisial atau foto orang, dengan lencana (badge) angka atau titik untuk notifikasi.

**Avatar:** ubin persegi `ev-r-md` 24, 32, 40, atau 56px (mengikuti ubin ikon halaman, bukan lingkaran). Foto mengisi ubin; tanpa foto, dua huruf inisial 600 di atas latar `ev-purple-600` (putih di atasnya 6,9:1). Beberapa orang bertumpuk dengan tumpang 8px dan cincin putih 2px; lebih dari tiga menjadi "+N".

**Lencana angka:** lencana `ev-gold` `ev-r-md` dengan angka `ev-gold-ink` 11/700 tinggi 18px, persis lencana jumlah pada tombol notifikasi di header halaman (kontras 8,9:1). Nilai di atas 99 ditulis "99+". **Lencana titik:** 10px, `ev-gold` dengan cincin putih, untuk tanda "ada yang baru" tanpa jumlah.

**Aturan:** lencana ditempatkan di pojok kanan atas dan tidak menutupi inisial. Setiap lencana punya teks pengganti untuk pembaca layar ("3 notifikasi belum dibaca").

**Responsif:** ukuran sama di semua layar; di desktop avatar di SideNav memakai 36px.

**Yang disediakan konsumen:** nama, foto, jumlah.
