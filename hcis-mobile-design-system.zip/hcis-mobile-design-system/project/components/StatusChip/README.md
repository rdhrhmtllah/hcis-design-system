Chip kecil yang menyatakan status satu pengajuan. Satu chip per pengajuan, di pojok kanan atas kartu dan di header Detail.

**Lima status:** Menunggu (`ev-wait-*`), Di HR (`ev-purple-100`, `ev-purple-800`, titik `ev-purple-600`), Disetujui (`ev-ok-*`), Ditolak (`ev-no-*`), Dibatalkan (`ev-cx-bg`, `ev-ink-2`, titik `ev-cx-dot`).

**Bentuk:** tinggi 24px, padding 0 10px, `ev-r-full`, teks gaya `chip`, titik 8px di kiri.

**State:** statis. Ukuran tidak berubah antar status; hanya warna dan kata.

**Yang disediakan konsumen:** kunci status. Kata dan warna ditentukan komponen. Jangan menambah status baru tanpa menentukan satu keluarga warna lengkap (isian, tinta, titik).

**Jangan:** memakai warna saja tanpa kata, memakai emas untuk status, atau menyebut "Diproses". Kata untuk tahap HR adalah "Di HR".

**Responsif:** Tidak berubah antar ukuran. Di [DataTable](../DataTable) chip tetap 26px dan selalu menyertakan label teks.
