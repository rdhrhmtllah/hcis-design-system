Bilah kemajuan: unggahan berkas, pemakaian kuota cuti, kelengkapan formulir.

**Susunan:** jalur tinggi 8px (`ev-r-full`) `ev-purple-100`, isian `ev-purple-600`. Untuk kuota: isian `ev-purple-600` yang telah terpakai dan sisa terang; di atas 90% isian berubah ke `ev-wait-dot` (peringatan), bukan merah. Label di atas bilah ("4 dari 12 hari terpakai") dan persentase di kanan bila perlu.

**Jenis:** pasti (nilai diketahui) dan tak-pasti (animasi bergeser, hanya saat durasi tak diketahui). Isian bertambah dengan `ev-ease-standard`.

**Aksesibilitas:** `role="progressbar"` dengan `aria-valuenow`, `aria-valuemin`, `aria-valuemax`, dan label. Makna tidak hanya warna: selalu ada teks.

**Responsif:** penuh lebar wadahnya di semua ukuran.

**Yang disediakan konsumen:** nilai, maksimum, label.
