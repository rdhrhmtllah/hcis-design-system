Daftar pasangan label dan nilai di dalam kartu: "Informasi" pada Detail pengajuan, atau ringkasan serupa. Ada dua bentuk dan keduanya pernah muncul di halaman.

**Bentuk A: daftar baris.** Kartu `ev-white`, `ev-r-2xl`, `ev-sh-card`, padding 14 / 16. Judul kartu 15/700 `ev-ink` dengan jarak bawah `ev-sp-4`. Tiap baris: label di kiri 13/600 `ev-ink-2` (tidak menyusut), nilai di kanan 13/800 `ev-ink` rata kanan, jarak antar keduanya minimal `ev-sp-16`, padding vertikal 10, garis atas 1px `ev-purple-50` (termasuk baris pertama).

**Bentuk B: kisi dua kolom.** Dipakai di bagian bawah kartu ringkasan (rentang, jenis, durasi, saldo). Garis putus 1.5px `ev-purple-100` di atas, jarak atas 12, `grid-template-columns:1fr 1fr`, jarak 12 / 10. Label 12/500 `ev-ink-2` di atas, nilai 14/700 `ev-ink` di bawah.

**Aturan:** label selalu kata benda pendek ("Diajukan", "Alasan", "Lampiran"); nilai tidak diakhiri titik. Nilai panjang (alasan) boleh membungkus ke bawah rata kanan, label tetap sebaris. Nilai kosong ditulis "–" (tanda hubung panjang), bukan baris dihilangkan, kecuali bila seluruh data memang tidak berlaku. Angka tabular. Tanggal dalam format "4 Nov 2026, 09:12". Nilai tidak bisa disalin otomatis kecuali berupa kode (tombol "Salin" di sisi kanan, ikon 18px).

**State:** statis. Memuat memakai [Skeleton](../Skeleton) dengan tinggi baris yang sama; galat tidak berlaku (data sudah ada saat kartu tampil).

**Aksesibilitas:** gunakan `dl`, `dt`, `dd` untuk bentuk A bila diimplementasikan di HTML sungguhan; di bentuk B juga.

**Responsif:** mobile satu kolom penuh. Tablet dan desktop: kartu berdampingan dalam kisi 12 kolom (Informasi di kanan, Status di kiri); bentuk A boleh berubah menjadi dua kolom label-nilai bila kartu lebih lebar dari 480px. *(usulan)*

**Yang disediakan konsumen:** judul kartu, daftar pasangan (label, nilai).
