Kartu ringkasan pemakaian cuti dalam setahun: angka total dan grafik batang dua belas bulan. Satu-satunya grafik di aplikasi karyawan; dipakai di atas halaman Riwayat. Bukan pustaka grafik umum: bentuknya khusus untuk "jumlah hari per bulan".

**Kartu:** `ev-white`, `ev-r-2xl`, `ev-sh-card`, padding `ev-sp-14`.
- **Atas:** label 12/600 `ev-ink-2` ("Cuti diambil tahun ini"), di bawahnya angka Bricolage 32/800 dengan satuan " hari" 15/600 `ev-ink-2` (huruf biasa, jarak 0). Di kanan, pil `ev-purple-100` (tinggi 26, `ev-r-md`, `ev-purple-800` 12/600): "4 hari potong saldo" (pembagian yang berguna, bukan ulangan angka utama).
- **Batang:** satu kolom per bulan, `flex:1`, jarak `ev-sp-6`, tinggi area 92, jarak batang ke label `ev-sp-4`, batang `ev-r-sm`. Tinggi batang = 16px + 14px x jumlah hari, tidak melebihi area; bulan tanpa cuti memakai batang 6px `ev-purple-100`.
- **Warna batang:** bulan berisi `ev-purple-300`; bulan yang disorot `ev-purple-600`; kosong `ev-purple-100`. Bulan di bawah batang satu huruf (J F M A M J J A S O N D) 12/600 `ev-ink-2`; bulan yang disorot 12/800 `ev-purple-800`. **Catatan:** di halaman referensi batang yang disorot (indeks 9, Oktober) dan huruf yang ditebalkan (indeks 10, November) berbeda bulan; ini tampak tidak sengaja. DS menetapkan keduanya jatuh pada bulan yang sama, yaitu bulan berjalan, dan perlu diperbaiki di halaman.
- **Animasi:** batang tumbuh dari dasar (`rbGrow` .7s `ev-ease-spring`) bergantian 40ms mulai 0.25s. Tanpa animasi di mode hemat gerak.

**Aturan:** grafik tidak membawa informasi yang tidak ada di teks: sediakan ringkasan teks untuk pembaca layar ("Cuti diambil 8 hari tahun ini. Oktober 3 hari, November 2 hari…"), grafik sendiri `aria-hidden` atau `role="img"` dengan `aria-label` berisi ringkasan itu. Tidak ada sumbu, garis kisi, atau legenda; jangan menambahkannya. Ketuk batang tidak melakukan apa-apa (tidak interaktif).

**Skala:** satu hari = 14px, maksimal enam hari terlukis penuh; lebih dari itu dipotong di tinggi area dan angkanya ditulis di atas batang (usulan).

**State:** berisi, kosong (semua batang 6px dan angka "0 hari"), memuat ([Skeleton](../Skeleton) kotak 92px).

**Responsif:** mobile lebar penuh. Tablet dan desktop: lebar kartu `ev-w-form` atau separuh kisi; tinggi area bertambah ke 120, satu hari = 18px. Batang tetap dua belas. *(usulan)*

**Yang disediakan konsumen:** total hari, hari yang memotong saldo, array dua belas angka, indeks bulan berjalan.
