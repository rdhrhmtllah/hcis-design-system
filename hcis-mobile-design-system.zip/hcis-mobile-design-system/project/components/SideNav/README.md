Navigasi utama untuk tablet dan desktop; menggantikan [BottomNav](../BottomNav) di layar 600px ke atas. **Seluruh komponen ini usulan**, tetapi dibuat dari bahasa visual Menu pada halaman referensi, bukan bentuk baru.

**Bahan:** latar gradasi `ev-purple-900` ke `ev-purple-800`; item memakai persis baris Menu: ubin ikon `ev-r-md` dengan tepi bawah 3px (`ev-purple-100` berikon `ev-purple-800`, tepi `ev-purple-300`) dan label putih 14/600. **Aktif:** baris putih penuh `ev-r-xl`, label `ev-ink`, ubin `ev-purple-600` berikon putih dengan tepi `ev-purple-800`.

**Dua bentuk**
- **Rel (tablet):** lebar `ev-w-rail` (72px); hanya ubin ikon 40px dengan label 11px di bawahnya. Lambang Evo (ubin emas `ev-r-md` dengan tepi `ev-gold-edge`) di atas, tombol Modul di dasar.
- **Sidebar (desktop):** lebar `ev-w-sidebar` (248px); lambang dan "HCIS" (Bricolage 800 putih) di atas, item di bawahnya, judul kelompok "Modul" (12/600 putih 85%, huruf kapital), dan profil di dasar sebagai baris kaca (putih 10%, garis putih 16%) berisi [Avatar](../Avatar).

**Isi:** Beranda, Presensi, Pengajuan, Profil (sama dengan BottomNav), ditambah "Semua modul" yang membuka [MenuOverlay](../MenuOverlay) dalam bentuk popover. Tombol Menu tiga dimensi dan gesture geser atas tidak dipakai.

**State:** normal, hover (putih 14%), fokus (cincin `ev-gold` 2px), aktif, ditekan (turun 1px), nonaktif (pudar 55%).

**Yang disediakan konsumen:** daftar tujuan, tujuan aktif, handler.

**Jangan:** lebih dari lima tujuan utama (sisanya di "Semua modul"), atau mengganti ubin ikon dengan lingkaran.
