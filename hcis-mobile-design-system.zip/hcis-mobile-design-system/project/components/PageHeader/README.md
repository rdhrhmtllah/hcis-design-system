Kepala halaman. Disalin dari halaman Cuti Saya, Notifikasi, Detail pengajuan, dan Ajukan cuti; tiap layar memakai kepala yang sama.

**Bentuk (lihat juga [Pola visual](../../patterns.md))**
- Latar gradasi `ev-purple-900` ke `ev-purple-700` (180 derajat), sudut bawah `ev-r-3xl`, dua cincin tipis (putih 8%) di kanan atas dan satu kilau `ev-gold`.
- **Tombol kembali:** area ketuk 44px berisi ubin 34px `ev-r-md` kaca (putih 16%, garis putih 22%) dengan panah putih. Hanya di halaman bertumpuk.
- **Judul:** Bricolage `title-l` 22/700 putih; keterangan `caption` `ev-purple-150`.
- **Aksi:** kapsul `ev-gold` tinggi 34px (`ev-r-lg`) dengan teks `ev-gold-ink` 12/600: "Sisa 8 hari", "Tandai dibaca", "11 jenis", "2026".

**Dua varian**
- **Halaman bertumpuk:** kembali, judul 22/700, keterangan, aksi emas di kanan.
- **Halaman utama (Cuti Saya):** judul `display-l` 32/800, ringkasan [SummaryChip](../SummaryChip) kaca di bawahnya.

**Tablet dan desktop (usulan):** kepala yang sama dibentangkan selebar area isi, tanpa tombol kembali (jejak halaman kaca di atas judul), aksi di kanan: satu tombol kaca sekunder dan satu tombol emas 3D utama (`ev-gold`, tepi 3px `ev-gold-edge`). Radius bawah tetap `ev-r-3xl`.

**State:** normal, dengan aksi, memuat (judul dan kapsul diganti [Skeleton](../Skeleton)).

**Aksesibilitas:** judul adalah satu-satunya `<h1>`; tombol kembali `aria-label="Kembali"`. Teks putih di atas `ev-purple-700` 8,9:1.

**Jangan:** lebih dari satu aksi, atau mengganti ubin kembali dengan lingkaran.

**Yang disediakan konsumen:** judul, keterangan, aksi, ringkasan.
