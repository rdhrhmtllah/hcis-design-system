Kartu angka ringkas: sisa cuti, jumlah menunggu, kehadiran bulan ini. Pasangan desktop dari [BalanceCard](../BalanceCard) bila ada banyak angka berdampingan.

**Susunan:** `ev-white`, radius `ev-r-xl`, bayangan `ev-sh-card`, padding `ev-sp-16`. Label `caption` `ev-ink-2` di atas, angka `display-l` (32/800 Bricolage, angka tabular) di tengah, satuan `body` di samping angka, keterangan atau tren `caption` di bawah. Ubin ikon 38px `ev-r-md` di pojok kanan atas dengan tepi bawah 3px, seperti ubin Menu: `ev-purple-100` dengan tepi `ev-purple-300` (atau `ev-gold` dengan tepi `ev-gold-edge` untuk satu kartu andalan).

**Tren:** panah naik/turun dengan teks, jangan hanya warna. Hijau (`ev-ok-ink`) untuk membaik, `ev-no-ink` untuk memburuk; netral `ev-ink-2`.

**State:** normal, hover bila bisa diketuk (naik 2px), memuat ([Skeleton](../Skeleton)), kosong ("0" dengan keterangan).

**Responsif:** mobile satu atau dua kolom; tablet tiga; desktop hingga empat kartu berjajar dalam kisi 12 kolom. *(usulan)*

**Yang disediakan konsumen:** label, nilai, satuan, keterangan, ikon.
