Jendela modal di tengah layar untuk konfirmasi dan formulir singkat. Di mobile fungsinya dipegang [Sheet](../Sheet); dari tablet ke atas, Sheet berubah menjadi Dialog. **Bentuk dialog adalah usulan.**

**Susunan:** latar gelap `ev-purple-900` 55%, panel `ev-white` radius `ev-r-2xl`, bayangan `ev-sh-sheet`. Lebar `ev-w-dialog-s` (konfirmasi) atau `ev-w-dialog-m` (formulir). Header: judul `title-m`, tombol tutup berupa ubin 34px `ev-r-md` `ev-purple-50` dalam area ketuk 44px (bukan lingkaran). Kaki: aksi sekunder di kiri (kontur), aksi utama di kanan (3D ungu).

**Jenis**
- **Konfirmasi:** satu kalimat tanya, dua tombol. Aksi merusak memakai tombol berbahaya.
- **Formulir:** judul, bidang, kaki aksi menempel di bawah saat isi panjang.

**Perilaku:** fokus masuk ke elemen pertama, terjebak di dalam dialog, `Esc` menutup, ketuk latar menutup (kecuali formulir yang belum disimpan). Fokus kembali ke pemicu. Masuk dengan skala 96% ke 100% dan pudar (`ev-ease-enter`, `ev-t-base`).

**State:** terbuka, memuat (tombol utama "Mengirim…"), galat (pesan di atas kaki).

**Z-index:** `ev-z-sheet`.

**Yang disediakan konsumen:** judul, isi, aksi.

**Jangan:** menumpuk dialog di atas dialog, atau memakai dialog untuk pesan yang cukup sebagai toast.
