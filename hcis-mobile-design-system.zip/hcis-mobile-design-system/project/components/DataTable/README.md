Tabel data untuk layar tablet dan desktop: daftar pengajuan dengan kolom, urutan, dan aksi per baris. Di mobile **tidak dipakai**; daftar yang sama tampil sebagai [RequestCard](../RequestCard). **Usulan.**

**Susunan:** kartu `ev-white` radius `ev-r-xl`, bayangan `ev-sh-card`. Kepala kolom 12/600 `ev-ink-2` huruf kapital, tinggi 44px, latar `ev-purple-50`. Baris tinggi 56px, garis pemisah `ev-purple-100`, teks `body`. Angka rata kanan dengan angka tabular. Status memakai [StatusChip](../StatusChip). Kolom terakhir berisi tombol "Aksi" yang membuka [Popover](../Popover).

**Kolom bawaan untuk pengajuan:** Jenis, Tanggal, Durasi, Status, Disetujui oleh, Aksi.

**Perilaku**
- Klik judul kolom mengurutkan (panah menunjukkan arah, `aria-sort`).
- Klik baris membuka panel detail (tablet) atau tampilan terbagi (desktop). Baris yang dipilih berlatar `ev-purple-50` dengan garis ungu 3px (`ev-purple-600`) di kiri, seperti baris belum dibaca.
- Hover baris: `ev-purple-50`. Fokus baris: cincin.
- Pilihan banyak (opsional): kolom pertama berisi kotak centang dan bilah aksi muncul di atas tabel.
- Kosong: [EmptyState](../EmptyState) di dalam kartu. Memuat: baris [Skeleton](../Skeleton).

**Responsif:** tablet menyembunyikan kolom "Disetujui oleh" dan "Durasi" (tersedia di detail); di bawah 600px berganti menjadi kartu. Tabel tidak pernah bergulir mendatar pada ukuran dukungan.

**Aksesibilitas:** `<table>` asli dengan `<th scope="col">`, urutan dan baris terpilih diumumkan.

**Yang disediakan konsumen:** kolom, baris, urutan, handler baris dan aksi.
