Kerangka abu bergerak yang dipakai saat data memuat, supaya tata letak tidak melompat.

**Bentuk:** meniru kartu atau baris asli (ubin tanggal, dua baris teks, chip) dengan balok abu `ev-purple-100` dan kilap yang menyapu dari kiri ke kanan (1,5 detik, berulang). Balok memakai radius dari skala (`ev-r-md`, `ev-r-lg`).

**Lama tampil:** muncul bersama halaman dan hilang begitu data siap. Jika memuat lebih lama dari beberapa detik, tambahkan pesan "Masih memuat…" atau tampilkan galat.

**State:** ada skeleton untuk kartu pengajuan, baris riwayat, dan baris notifikasi. Dengan "kurangi gerakan", kilap berhenti dan balok tetap tampil.

**Yang disediakan konsumen:** jenis kerangka dan jumlah baris.

**Jangan:** memakai skeleton untuk keadaan kosong atau galat, atau membuat bentuk yang tidak sama dengan isi aslinya.

**Responsif:** Bentuk skeleton mengikuti komponen yang dimuat pada ukuran layar itu: kartu di mobile, baris tabel di desktop.
