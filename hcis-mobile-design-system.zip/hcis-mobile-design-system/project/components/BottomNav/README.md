Navigasi bawah tetap dengan lima tujuan dan tombol Menu di tengah yang menonjol.

**Susunan:** panel putih bersudut `ev-r-3xl` yang melayang di tepi bawah; empat tujuan berikon dan berlabel (Beranda, Presensi, Pengajuan, Profil) dan tombol Menu 56px yang menjorok ke atas di tengah. Tujuan aktif memakai `ev-purple-800` dengan penanda kecil; yang lain `ev-ink-2`.

**Tombol Menu:** kotak `ev-r-xl` bergradasi `ev-purple-400` ke `ev-purple-700`, bingkai putih 4px, bayangan ungu, berisi lambang rumah Evo (dua nada emas) dengan kilau kecil yang berkedip setiap beberapa detik. Saat menu terbuka ikonnya menjadi tanda silang.

**Gesture:** geser atas dari tombol Menu membuka menu (komit setelah 48px); di dalam menu geser bawah menutup dan geser kiri atau kanan berpindah modul. Tombol Menu tetap bisa diketuk sebagai jalan biasa. Panah petunjuk muncul maksimal 3 kali sampai gesture dipakai.

**State:** tujuan aktif, tombol Menu tertutup, tombol Menu terbuka, ditekan.

**Yang disediakan konsumen:** tujuan aktif dan handler navigasi.

**Catatan:** lambang rumah pada tombol adalah gambar ulang sederhana dari logo Evo Group, bukan berkas resmi. Ganti dengan SVG resmi dari tim brand begitu ada (lihat aset Logos).

**Responsif:** Hanya untuk mobile (sampai 599px). Dari 600px ke atas diganti [SideNav](../SideNav); tombol Menu dan geser atas berganti menjadi tombol "Modul" yang membuka [Popover](../Popover). *(usulan)*
