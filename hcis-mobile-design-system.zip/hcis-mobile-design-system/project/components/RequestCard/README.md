Kartu satu pengajuan di daftar "Pengajuan aktif". Satu kartu memuat kode, status, tanggal, jenis, dan stepper mendatar.

**Susunan:** kode (`label`) di kiri atas dan `StatusChip` di kanan atas; ubin tanggal (bulan dan hari) di kiri; rentang tanggal (`title-m`, Bricolage) dan keterangan (jenis dan lama) di sampingnya; panah buka di kanan; di bawah, baris `ev-purple-50` berisi kalimat status dan `ApprovalStepper` mendatar.

**Gesture:** geser kiri lebih dari 60px membuka baki dua aksi: **Ingatkan** (isian `ev-gold`, teks `ev-gold-ink`) dan **Batalkan** (isian `ev-no-dot`, teks putih). Setiap aksi juga ada sebagai tombol di halaman Detail. Baris mengintip sebagai petunjuk (maksimal 3 kali) sampai gesture-nya dipakai.

**State yang harus ada:** normal, baru (disorot sebentar saat baru dibuat), baki aksi terbuka, skeleton (`Skeleton`), kosong (`EmptyState`).

**Yang disediakan konsumen:** kode, status, tanggal, rentang, jenis, lama, tahap, dan handler buka, ingatkan, batalkan. Ketuk membuka Detail.

**Jangan:** menyembunyikan aksi hanya di balik gesture, atau menambahkan lebih dari dua aksi di baki.

**Responsif:** Mobile: satu kolom, aksi lewat geser. Tablet: dua kolom, tombol "Ingatkan" dan "Batalkan" tampak di kartu. Desktop: diganti [DataTable](../DataTable). Gesture geser hanya aktif pada layar sentuh. *(usulan)*
