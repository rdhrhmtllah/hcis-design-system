Deretan chip kecil yang menyatakan siapa yang menyetujui, berurutan, tanpa menunjukkan status. Di halaman dipakai di Ketentuan ("Kamu > Atasan > HR"). Untuk alur yang sedang berjalan dengan status per tahap, pakai [ApprovalStepper](../ApprovalStepper).

**Susunan:** baris yang boleh membungkus (`flex-wrap`), jarak `ev-sp-4`. Tiap chip tinggi 28, padding 0 11px, `ev-r-lg`, 13/700. Chip pertama ("Kamu") terisi: `ev-purple-600`, teks putih. Chip lain: `ev-purple-50` dengan teks `ev-purple-800`. Di antara chip ada panah 16px, garis 2.6, warna `ev-purple-400`.

**Pembungkus yang dipakai bersama:** judul jenis (14/700 `ev-ink`) di kiri dan jumlah tahap (12/600 `ev-ink-2`, misalnya "2 tahap") di kanan pada baris sendiri, lalu path 6px di bawahnya; satu baris keterangan 13/500 `ev-ink-2` ("HR memeriksa saldo cuti.") boleh menyusul. Antar jenis dipisah garis 1px `ev-purple-50`, jarak vertikal 10px.

**Aturan:** jumlah tahap tidak menghitung "Kamu" (Kamu > Atasan > HR = 2 tahap). Nama peran saja, bukan nama orang. Maksimal lima chip; lebih dari itu ringkas menjadi "Kamu > Atasan > +3 tahap". Panah bersifat dekoratif (`aria-hidden`); untuk pembaca layar, bungkus path dengan `aria-label="Alur: Kamu, Atasan, HR"`.

**State:** hanya satu (statis). Tidak bisa diketuk.

**Responsif:** membungkus alami pada lebar sempit; di desktop tetap satu baris. Tidak ada perubahan bentuk.

**Yang disediakan konsumen:** daftar peran berurutan; chip pertama otomatis "Kamu".
