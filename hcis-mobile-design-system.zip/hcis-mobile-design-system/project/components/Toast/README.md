Pesan singkat yang melayang di atas navigasi bawah. Lima jenis: **loading**, **berhasil**, **gagal**, **peringatan**, **info**.

**Susunan:** isian lembut berwarna sesuai jenis, garis tepi jenis, cakram ikon bergradasi di kiri, judul `heading-s` dan satu baris keterangan, tombol aksi pill di kanan (misalnya "Urungkan", "Coba lagi"), dan batang waktu tipis di tepi bawah yang menyusut sampai toast hilang.

| Jenis | Isian | Cakram | Dipakai untuk |
| --- | --- | --- | --- |
| loading | `ev-purple-50` | ungu | proses berjalan ("Mengirim pengingat…") |
| berhasil | hijau muda | hijau | hasil sukses, dengan aksi Urungkan bila bisa dibalik |
| gagal | mawar muda | mawar | galat, dengan aksi "Coba lagi" |
| peringatan | oranye muda | oranye | batasan atau jeda ("Sudah diingatkan, coba lagi nanti") |
| info | `ev-purple-50` | ungu | informasi netral |

**Perilaku:** muncul dengan `ev-ease-spring`, keluar dengan `ev-ease-exit`. Toast gagal bergetar sekali. Toast loading tidak punya batang waktu dan diganti hasilnya (berhasil atau gagal). Bisa digeser ke samping (lebih dari 70px) atau ke bawah (36px) untuk menutup. Hanya satu toast pada satu waktu; yang baru menggantikan yang lama.

**Yang disediakan konsumen:** jenis, judul, keterangan, aksi (opsional), durasi. Gunakan `aria-live` "polite" untuk berhasil, info, dan loading; "assertive" untuk gagal.

**Jangan:** memakai toast untuk keputusan yang butuh persetujuan (pakai `Sheet`), menaruh lebih dari satu aksi, atau menulis pesan galat tanpa langkah berikutnya.

**Responsif:** Mobile: di atas BottomNav, tengah. Tablet dan desktop: pojok kanan bawah, lebar tetap 360px, bertumpuk ke atas dengan jarak `ev-sp-8`. Tetap `ev-z-toast`. *(usulan)*
