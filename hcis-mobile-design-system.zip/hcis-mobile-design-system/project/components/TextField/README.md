Kolom isian teks: satu baris dan banyak baris. Disalin dari kolom "Alasan cuti" pada halaman Ajukan cuti.

**Bentuk:** padding 10px 12px, `ev-r-lg`, garis 1,5px `ev-purple-150`, latar `ev-field-bg`, teks 14/500 dengan tinggi baris 1,45, placeholder `ev-ink-2`. Banyak baris: tinggi 84px, tanpa tarik-ubah-ukuran. Satu baris: tinggi 48px.

**Label:** 12/600 `ev-ink` di atas kolom, selalu tampak (placeholder bukan pengganti label). Dalam kartu bernomor, label diganti judul kartu.

**Kaki:** teks bantu di kiri, penghitung di kanan ("34 / 200", `caption`). Batas karakter dipasang lewat `maxlength`.

**State**
- **Normal:** seperti di atas.
- **Fokus:** garis `ev-purple-600` dan kontur 2px `ev-purple-600` berjarak 2px. Jangan dihapus.
- **Galat:** garis `ev-no-dot`, pesan 12/500 `ev-no-ink` dengan ikon, `aria-invalid` dan `aria-describedby`. Pesan menyebut cara memperbaiki ("Isi alasan minimal 5 karakter").
- **Nonaktif:** latar `ev-purple-50`, teks `ev-ink-2`.

**Aturan:** validasi setelah bidang ditinggalkan, bukan saat mengetik. Tombol utama formulir tetap nonaktif dan menyebut apa yang kurang ("Isi alasan cuti"). Ukuran huruf pada perangkat sentuh minimal 16px agar iOS tidak memperbesar halaman. *(usulan, belum ada di halaman)*

**Responsif:** mobile penuh lebar; tablet dan desktop dibatasi `ev-w-form` (560px), bidang berpasangan boleh berdampingan di desktop. *(usulan)*

**Yang disediakan konsumen:** label, nilai, batas, aturan validasi, pesan.
