Pustaka ikon HCIS Mobile: **49 ikon**, semuanya digambar dengan garis (outline) di kanvas 24x24, ujung dan sambungan bulat. Setiap path diambil persis dari halaman Cuti Saya; nama diberikan di sini supaya ikon yang sama selalu dipanggil dengan nama yang sama. Jangan menggambar ikon baru atau memakai pustaka ikon pihak ketiga; bila ikon yang dibutuhkan tidak ada, tambahkan ke daftar ini dengan gaya yang sama.

**Aturan gambar:** `viewBox="0 0 24 24"`, `fill="none"`, `stroke="currentColor"`, `stroke-linecap="round"`, `stroke-linejoin="round"`, `aria-hidden="true"`. Warna ikon selalu mengikuti `color` pembungkusnya; jangan mengisi warna langsung. Ikon tidak pernah berdiri sendiri sebagai satu-satunya penanda arti: sertakan teks atau `aria-label` di tombol pembungkusnya.

**Ukuran dan tebal garis:** tebal garis dipilih menurut ukuran, bukan selera. Semakin kecil ikon, semakin tebal garis supaya tetap terbaca.
| Ukuran (px) | Dipakai untuk | Tebal garis |
|---|---|---|
| 11 | badge centang kecil | 4 |
| 15 | ikon di dalam tombol kapsul (Unduh, Ulangi) | 2.6 |
| 18 | ikon tombol dan baris aksi | 2.2 sampai 2.6 |
| 20 | ikon ubin 40px, tab, header | 2 sampai 2.3 |
| 22 | ikon ubin modul 42 sampai 44px | 2.2 sampai 2.4 |
| 26 | ikon ubin pintasan 52px | 2 |
| 30 | ikon hero (cakram sukses) | 3.2 |

**Warna ikon di ubin:** ikon memakai tinta keluarga ubinnya. Ungu `ev-purple-800` di atas `ev-purple-100`, hijau `ev-ok-ink` di atas `ev-ok-bg`, biru `ev-info-ink` di atas `ev-info-bg`, oranye `ev-wait-ink` di atas `ev-wait-bg`, mawar `ev-no-ink` di atas `ev-no-bg`. Di atas `ev-gold` pakai `ev-ok-ink` atau `ev-gold-ink`. Di atas isian ungu penuh pakai putih. Ikon pada tombol berbahaya putih; pada tombol kontur berbahaya `ev-no-ink`.

**Area ketuk:** ikon 18 sampai 22px yang bisa diketuk selalu berada dalam area 44x44 (ubin 34px dengan jarak di sekelilingnya). Ukuran ikon tidak membesar agar muat.

**Kerlip empat sudut** (hiasan emas dan ungu di layar hasil dan header): path `M12 1l2.6 8.4L23 12l-8.4 2.6L12 23l-2.6-8.4L1 12l8.4-2.6z`, diisi (bukan garis), ukuran 12 sampai 16px, warna `ev-gold`, `ev-purple-400`, atau `ev-purple-300`. Hanya untuk dekorasi dan `aria-hidden`.

**Bintang** (peringkat, 14px, diisi): `m12 2.5 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4 6.1 20.5l1.2-6.5L2.5 9.4l6.6-.9z`.

**Pemuat berputar:** cincin 22px (`r=8.5`, garis 3) dengan busur `ev-purple-600` di atas cincin `ev-purple-600` 20%, berputar 0.8 detik linear. Dengan `prefers-reduced-motion` diganti tiga titik berdenyut.

**Daftar lengkap**
| Nama | Dipakai untuk | Ukuran umum | Garis |
|---|---|---|---|
| `check` | centang terpilih, badge | 12px | 4 |
| `close` | tutup sheet, silang | 18px | 2.6 |
| `plus` | tambah, FAB | 22px | 3 |
| `chevron-right` | masuk ke detail, pemisah path | 16px | 2.6 |
| `chevron-left` | sebelumnya (kalender, tahap) | 20px | 2.6 |
| `chevron-down` | buka akordeon, pilih | 16px | 2.6 |
| `arrow-right` | lanjut, kirim | 20px | 2.6 |
| `arrow-left` | kembali di header | 20px | 2.6 |
| `swap` | beralih aplikasi | 18px | 2.4 |
| `search` | cari | 20px | 2.2 |
| `refresh` | muat ulang | 22px | 2.6 |
| `retry` | ulangi proses | 15px | 2.6 |
| `rotate-ccw` | bisa diajukan ulang | 20px | 2.3 |
| `history` | riwayat | 26px | 2 |
| `clock` | waktu, absen | 20px | 2.3 |
| `calendar` | cuti, jadwal | 22px | 2.3 |
| `calendar-days` | jenis cuti | 26px | 2 |
| `calendar-check` | tab Cuti | 18px | 2 |
| `calendar-x` | tanggal bentrok | 22px | 2.2 |
| `document` | berkas | 20px | 2.2 |
| `document-lines` | ketentuan, panduan | 26px | 2 |
| `video` | video panduan | 20px | 2.1 |
| `folder` | modul dokumen | 22px | 2.2 |
| `id-card` | modul ESS | 22px | 2.2 |
| `bar-chart` | modul laporan, KPI | 22px | 2.2 |
| `trend` | modul TPM | 20px | 2.2 |
| `graduation` | modul LMS | 22px | 2.2 |
| `user-check` | modul absensi, orang disetujui | 16px | 2.2 |
| `activity` | panel aktivitas | 18px | 2 |
| `bell` | notifikasi | 18px | 2 |
| `help` | bantuan | 18px | 2 |
| `info` | info (ⓘ) | 20px | 2 |
| `alert` | seru dalam toast galat | 18px | 3.4 |
| `warning` | sistem sibuk | 22px | 2.2 |
| `alert-circle` | saldo tidak cukup | 22px | 2.2 |
| `wifi-off` | koneksi terputus | 20px | 2.3 |
| `ban` | dihentikan | 20px | 2.3 |
| `wallet` | saldo | 20px | 2.3 |
| `banknote` | cuti tanpa gaji | 20px | 2.2 |
| `heart` | cuti khusus | 20px | 2.2 |
| `trash` | hapus, batalkan | 18px | 2.6 |
| `download` | unduh | 15px | 2.6 |
| `upload` | unggah | 20px | 2.4 |
| `logout` | keluar | 22px | 2.2 |
| `play` | mulai tur | 16px | 2.4 |
| `route` | tur, jalur | 22px | 2.4 |
| `chat` | chat PIC | 18px | 2.2 |
| `phone` | telepon PIC | 18px | 2.2 |
| `mail` | email PIC | 18px | 2.2 |

**Data (salin langsung).** Objek JSON `nama: isi svg`; bungkus dengan aturan gambar di atas.
```json
{"check": "<path d=\"m5 12.5 4.5 4.5L19 7.5\"/>", "close": "<path d=\"M6 6l12 12M18 6 6 18\"/>", "plus": "<path d=\"M12 5v14M5 12h14\"/>", "chevron-right": "<path d=\"m9 6 6 6-6 6\"/>", "chevron-left": "<path d=\"m15 6-6 6 6 6\"/>", "chevron-down": "<path d=\"m6 9 6 6 6-6\"/>", "arrow-right": "<path d=\"M5 12h14M13 6l6 6-6 6\"/>", "arrow-left": "<path d=\"M19 12H5M11 6l-6 6 6 6\"/>", "swap": "<path d=\"M7 7h12l-3-3M17 17H5l3 3\"/>", "search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"m16 16 4 4\"/>", "refresh": "<path d=\"M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7\"/>", "retry": "<path d=\"M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5\"/>", "rotate-ccw": "<path d=\"M20 12a8 8 0 1 1-2.6-5.9M20 4v4.5h-4.5\"/>", "history": "<path d=\"M3.5 12a8.5 8.5 0 1 0 2.6-6.1\"/><path d=\"M3.5 4.5v4h4\"/><path d=\"M12 7.5V12l3 2\"/>", "clock": "<path d=\"M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM12 7.8V12l3 2\"/>", "calendar": "<path d=\"M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM4 10h16M8 2.8V6M16 2.8V6\"/>", "calendar-days": "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"15.5\" rx=\"4\"/><path d=\"M8 3v4M16 3v4M3.5 10h17\"/><path d=\"M8 14h.01M12 14h.01M16 14h.01M8 17.4h.01M12 17.4h.01\"/>", "calendar-check": "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"15.5\" rx=\"4\"/><path d=\"M8 3v4M16 3v4M3.5 10h17\"/><path d=\"m9 15 2.2 2.2L15.5 13\"/>", "calendar-x": "<path d=\"M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM4 10h16M9.5 13.5l5 5M14.5 13.5l-5 5\"/>", "document": "<path d=\"M14 3.5H7.5A1.5 1.5 0 0 0 6 5v14a1.5 1.5 0 0 0 1.5 1.5h9A1.5 1.5 0 0 0 18 19V7.5zM14 3.5v4h4\"/>", "document-lines": "<path d=\"M14 3.5H7.5A1.5 1.5 0 0 0 6 5v14a1.5 1.5 0 0 0 1.5 1.5h9A1.5 1.5 0 0 0 18 19V7.5z\"/><path d=\"M14 3.5v4h4\"/><path d=\"M9 12h6M9 15.5h6\"/>", "video": "<path d=\"M5 6.5h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM17 11l4-2.5v7L17 13\"/>", "folder": "<path d=\"M3.5 7.5a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z\"/>", "id-card": "<path d=\"M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z\"/><path d=\"M9 9a2 2 0 1 1 0 4 2 2 0 0 1 0-4z\"/><path d=\"M6.5 16c.5-1.6 1.6-2.4 2.5-2.4s2 .8 2.5 2.4\"/><path d=\"M14 10h4M14 13.5h3\"/>", "bar-chart": "<path d=\"M4 20h16\"/><path d=\"M7 17v-5M12 17V7M17 17v-8\"/>", "trend": "<path d=\"M4 19.5V5M4 19.5h16M8 15l3-4 3 2.5 5-6\"/>", "graduation": "<path d=\"M2.5 9.5 12 5l9.5 4.5L12 14z\"/><path d=\"M6.5 11.8V16c0 1.2 2.5 2.5 5.5 2.5s5.5-1.3 5.5-2.5v-4.2\"/><path d=\"M21.5 9.5V14\"/>", "user-check": "<circle cx=\"9\" cy=\"8\" r=\"3.5\"/><path d=\"M3 20c.5-3.6 3-5.5 6-5.5s5.5 1.9 6 5.5\"/><path d=\"m16 11 2 2 3.5-4\"/>", "activity": "<rect x=\"3.5\" y=\"4\" width=\"17\" height=\"16\" rx=\"4.5\"/><path d=\"M7 12.5h2l1.5-3.2 3 6 1.5-2.8h2\"/>", "bell": "<path d=\"M6 9a6 6 0 1 1 12 0c0 5 2 6.5 2 6.5H4S6 14 6 9z\"/><path d=\"M10 19a2 2 0 0 0 4 0\"/>", "help": "<circle cx=\"12\" cy=\"12\" r=\"9.5\"/><path d=\"M9.6 9.4a2.5 2.5 0 1 1 3.6 2.2c-.8.4-1.2.9-1.2 1.8\"/><path d=\"M12 17h.01\"/>", "info": "<circle cx=\"12\" cy=\"12\" r=\"9.5\"/><path d=\"M12 11v5\"/><path d=\"M12 7.8h.01\"/>", "alert": "<path d=\"M12 5.5v8M12 18.2h.01\"/>", "warning": "<path d=\"M12 4 2.8 19.5h18.4zM12 10v4.5M12 17.4h.01\"/>", "alert-circle": "<path d=\"M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7.5v5.5M12 16.4h.01\"/>", "wifi-off": "<path d=\"M2 8.8a15 15 0 0 1 4-2.4M22 8.8a15 15 0 0 0-8.6-3.6M5 12.9a10 10 0 0 1 3.6-2M19 12.9a10 10 0 0 0-3.4-2.1M8.5 16.4a5 5 0 0 1 7 0M12 20h.01M3 3l18 18\"/>", "ban": "<path d=\"M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM6 6l12 12\"/>", "wallet": "<path d=\"M4 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7zm0 0v-.5A2.5 2.5 0 0 1 6.5 4H16M16 14h2\"/>", "banknote": "<path d=\"M4 7.5h14a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM4 7.5 16 4v3.5M16 14h.01\"/>", "heart": "<path d=\"M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z\"/>", "trash": "<path d=\"M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12\"/>", "download": "<path d=\"M12 4v11M7 11l5 5 5-5M5 20h14\"/>", "upload": "<path d=\"M12 16V5M7 9l5-5 5 5M5 20h14\"/>", "logout": "<path d=\"M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4\"/><path d=\"m10 8 4 4-4 4M14 12H4\"/>", "play": "<path d=\"M8 5.5v13l11-6.5z\"/>", "route": "<path d=\"M4 18c4 0 3-6 8-6s3-6 8-6M4 18h.01M20 6h.01\"/>", "chat": "<path d=\"M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H11l-4.5 3.5V17H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z\"/>", "phone": "<path d=\"M6.5 4h3l1.5 4-2 1.3a10 10 0 0 0 5.7 5.7L16 13l4 1.5v3A2.5 2.5 0 0 1 17.5 20 13.5 13.5 0 0 1 4 6.5 2.5 2.5 0 0 1 6.5 4z\"/>", "mail": "<path d=\"M4 6.5h16v11H4zM4 7.5l8 6 8-6\"/>"}
```

**Ikon yang masih kurang (usulan, belum ada di halaman):** `edit`, `filter`, `more` (tiga titik), `sort`, `copy`, `eye`, `settings`, `home`, `user`. Beberapa sudah ada di preview komponen lain (BottomNav, DataTable) dengan gaya yang sama; bila dipakai di halaman, daftarkan dengan nama di atas.

**Responsif:** ikon tidak berubah antar perangkat. Di desktop, ubin ikon SideNav dan header boleh naik satu langkah ukuran (20 ke 22) dengan tebal garis yang sama. *(usulan)*
