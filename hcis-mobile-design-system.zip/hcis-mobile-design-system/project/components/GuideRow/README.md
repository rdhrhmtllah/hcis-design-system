Baris dokumen panduan: PDF atau video yang bisa dibuka dari tab "Panduan". Bentuknya sama dengan [JobRow](../JobRow) (ubin 40px, judul, keterangan, satu aksi di kanan) supaya daftar bantuan dan daftar proses terasa satu keluarga.

**Susunan:** `ev-white`, `ev-r-xl`, `ev-sh-row`, margin 0 / 14 / 8, padding 10 / 6 / 10 / 12, jarak `ev-sp-12`.
- **Ubin 40px `ev-r-md`** dengan garis 1px dan ikon 20px (garis 2.1). Warna menurut jenis: dokumen ESS ungu, video biru, panduan modul yang belum rilis oranye. Ikon: dokumen untuk PDF, kamera untuk video.
- **Tengah:** judul 14/600 dan keterangan 12/500 `ev-ink-2` ("PDF · 12 hlm · Okt 2026", "Video · 3 menit"), masing-masing satu baris dengan elipsis.
- **Kanan, tersedia:** tombol "Buka" (area 44px, ubin 34px `ev-r-lg`, `ev-purple-100`, teks `ev-purple-800` 13/700).
- **Kanan, belum rilis:** teks "Belum tersedia" 12/600 `ev-ink-2`, seluruh baris opasitas .75, tidak bisa diketuk.

**Catatan bawah daftar:** "Panduan yang belum tersedia akan muncul otomatis begitu dirilis." (12/500 `ev-ink-2`).

**Aturan:** keterangan wajib memuat jenis dan ukuran (halaman atau menit) agar pengguna tahu apa yang akan dibuka. `aria-label` tombol "Buka <judul>". Panduan dibuka di tab baru atau penampil dokumen; jangan mengunduh otomatis.

**State:** normal, ditekan (latar baris `ev-tint`), fokus (garis 2px `ev-purple-600` di tombol), belum tersedia.

**Responsif:** sama di semua ukuran; di desktop daftar boleh dua kolom di panel lebar. *(usulan)*

**Yang disediakan konsumen:** judul, keterangan, jenis (menentukan ikon dan warna), ketersediaan, handler buka.
