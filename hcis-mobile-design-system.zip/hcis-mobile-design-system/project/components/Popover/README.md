Panel kecil yang melayang di dekat pemicunya: menu aksi, pilihan, atau modul. Dipakai terutama di tablet dan desktop, sebagai pengganti sheet kecil. **Usulan.**

**Susunan:** panel `ev-white`, radius `ev-r-lg`, bayangan `ev-sh-pop`, padding `ev-sp-6`. Item tinggi 44px, ikon 20px, label 14/600. Item berbahaya memakai `ev-no-ink`. Pemisah garis `ev-purple-100`.

**Penempatan:** muncul di bawah pemicu, rata kiri; membalik ke atas atau ke sisi lain bila tidak muat, tetap ada jarak `ev-sp-8` dari layar.

**Perilaku:** buka dengan klik atau Enter, tutup dengan `Esc`, klik di luar, atau memilih item. Panah atas/bawah memindah sorotan, Enter memilih. Fokus kembali ke pemicu. Masuk dengan pudar 120ms.

**Dipakai oleh:** menu "Aksi" pada baris [DataTable](../DataTable), pemilih modul, menu profil, [Select](../Select).

**State item:** normal, hover/sorot (`ev-purple-50`), fokus, nonaktif, berbahaya.

**Z-index:** `ev-z-popover`.

**Yang disediakan konsumen:** daftar item (ikon, label, handler).
