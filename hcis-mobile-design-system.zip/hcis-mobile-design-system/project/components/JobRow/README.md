Satu baris proses latar belakang: export, unduhan, atau tugas terjadwal. Dipakai di [ActivityPanel](../ActivityPanel) dan boleh dipakai di daftar proses lain. Isinya berubah menurut keadaan, bentuk bajanya tetap.

**Wadah:** `ev-white`, `ev-r-xl`, bayangan `ev-sh-row`, margin 0 / 14 / 8, padding 10 / 6 / 10 / 12, jarak isi `ev-sp-12`, isi sejajar tengah.

**Ubin jenis berkas:** 40px, `ev-r-md`, garis 1px, teks ekstensi 12/600 (`letter-spacing:.2px`). Warna menurut jenis berkas, tetap:
| Berkas | Isian | Tepi | Tinta |
|---|---|---|---|
| XLSX | `ev-ok-bg` | `ev-ok-edge` | `ev-ok-ink` |
| PDF | `ev-no-bg` | `ev-no-edge` | `ev-no-ink` |
| CSV | `ev-info-bg` | `ev-info-edge` | `ev-info-ink` |
| Lainnya | `ev-purple-100` | `ev-purple-edge` | `ev-purple-800` |

**Tengah:** judul 14/600 satu baris dengan elipsis; di bawahnya, menurut keadaan, bilah kemajuan atau keterangan 12/500.

**Keadaan dan aksi di kanan:**
| Keadaan | Tengah bawah | Aksi |
|---|---|---|
| Berjalan | bilah 6px (`ev-purple-100` dengan isian `ev-purple-600`, `ev-r-xs`) dan persen 12/600 `ev-purple-800` | teks "Batal" 13/600 `ev-ink-2`, area 56x44 |
| Selesai | keterangan, misalnya "4 Nov · 124 KB" | tombol "Unduh": tinggi 34, `ev-r-lg`, `ev-purple-600`, putih 13/700, ikon unduh 15px |
| Sudah diunduh | keterangan | "Terunduh": `ev-ok-bg`, teks `ev-ok-ink`, ikon sama |
| Gagal | keterangan `ev-no-ink`, misalnya "Gagal · koneksi terputus" | "Ulangi": `ev-no-bg`, teks `ev-no-ink`, ikon ulang 15px |
| Terjadwal | keterangan, misalnya "Setiap Senin · 07.00" | sakelar 44x26 (lihat [SelectionControls](../SelectionControls)): `ev-purple-600` menyala, `ev-purple-edge` mati, area 60x44 |

**Aturan:** semua area ketuk tinggi 44px walau tombolnya tampak 34px. Aksi selalu satu per baris. Teks tombol kata kerja ("Unduh", "Ulangi", "Batal"); `aria-label` lengkap dengan judul ("Unduh Export riwayat cuti"). Persen diperbarui lewat `aria-valuenow` pada bilah (`role="progressbar"`), bukan lewat pembacaan ulang.

**State:** normal, ditekan (latar baris `ev-tint`), fokus (garis 2px `ev-purple-600` di sekeliling tombol aksi), berpindah antar grup (baris masuk bergantian 40ms, `motion.md`).

**Responsif:** mobile satu kolom penuh lebar panel. Tablet dan desktop: di dalam panel `ev-w-panel`, bentuk sama; bila dipakai sebagai halaman, [DataTable](../DataTable) menggantikannya dengan kolom Nama, Status, Aksi. *(usulan)*

**Yang disediakan konsumen:** judul, ekstensi, keadaan, persen atau keterangan, handler batal, unduh, ulangi, dan sakelar.
