Pilihan satu dari daftar tertutup (jenis cuti, atasan, periode). Tampil seperti [TextField](../TextField) dengan panah.

**Susunan:** pemicu setinggi 48px dengan nilai terpilih dan panah bawah. Daftar pilihan:
- **Mobile:** [Sheet](../Sheet) dari bawah dengan daftar bertinggi 52px per baris, centang di sisi kanan untuk yang terpilih.
- **Tablet dan desktop (usulan):** [Popover](../Popover) di bawah pemicu, lebar sama dengan pemicu, maksimal 8 baris sebelum bergulir.

**Perilaku:** Enter, Spasi, atau panah bawah membuka; panah memindah sorotan; huruf awal melompat ke item; Enter memilih; `Esc` menutup. Lebih dari 8 pilihan: tambahkan kolom cari di atas daftar.

**State:** normal, hover, fokus, terbuka (panah berputar 180 derajat), galat, nonaktif, memuat (daftar menampilkan [Skeleton](../Skeleton)).

**Item:** normal, sorot (`ev-purple-50`), terpilih (`ev-purple-800` tebal dan centang), nonaktif (`ev-ink-3` hanya bila disertai alasan).

**Yang disediakan konsumen:** label, opsi, nilai, handler.

**Jangan:** memakai Select untuk dua atau tiga pilihan (pakai pilihan segmen atau radio).
