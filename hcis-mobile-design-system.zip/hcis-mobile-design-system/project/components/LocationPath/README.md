Isi panel "Lokasi saya": menunjukkan di mana pengguna berada dalam hierarki aplikasi, menu lain pada modul yang sama, dan jalan pindah ke aplikasi lain. Dibuka dari tombol jalur (breadcrumb) di header. Pengganti breadcrumb horizontal yang tidak muat di mobile.

**Bagian 1: JALUR HALAMAN.** Label 12/600 huruf kapital `ev-purple-accent`, jarak huruf .4px, lalu kartu `ev-white` `ev-r-xl` `ev-sh-row` dengan padding 8 / 16 / 6. Setiap tingkat adalah satu baris tinggi minimal 52 dengan **rel vertikal** di kiri (lebar 20px): garis 2px `ev-purple-edge` (`ev-r-hair`) menyambung dari titik ke titik, titik 10px putih dengan garis 2px `ev-purple-400`. Tingkat sekarang memakai titik 14px `ev-gold` bergaris 2px `ev-gold-edge` dengan halo 4px emas 35%, judul 15/800 `ev-ink`, dan chip "Di sini" (tinggi 24, `ev-r-md`, `ev-gold`, garis `ev-gold-edge`, `ev-gold-ink` 12/600). Tingkat lain: judul 15/700 `ev-purple-800`, panah kanan 16px `ev-ink-3`. Di bawah judul ada keterangan 12/500 `ev-ink-2` ("Employee Self Service", "Halaman ini"). Baris masuk bergantian 60ms.

**Bagian 2: MENU LAIN DI <MODUL>.** Label sama, lalu chip menu pada modul itu, membungkus, jarak `ev-sp-6`. Chip: area 44px, kapsul 36px `ev-r-xl`, 13/600. Menu saat ini terisi `ev-purple-800` dengan teks putih; lainnya putih dengan garis 1px `ev-purple-edge` dan teks `ev-purple-800`.

**Bagian 3: tombol alih aplikasi.** Penuh lebar, tinggi 48, `ev-r-lg`, putih dengan garis 1px `ev-purple-edge`, ikon tukar 18px, label "Beralih ke HCIS Tim" 14/700 `ev-purple-800`.

**Aturan:** jalur maksimal empat tingkat; tingkat sekarang selalu terakhir. Setiap tingkat selain terakhir bisa diketuk dan menutup panel lalu pindah halaman. `aria-label="Breadcrumb"` pada `nav` dan `aria-current="page"` pada tingkat sekarang. Tombol alih aplikasi hanya tampil bila pengguna punya akses ke aplikasi lain.

**State:** normal, ditekan (latar baris `ev-tint`), fokus (garis 2px `ev-purple-600`); tidak ada keadaan kosong (jalur selalu ada).

**Responsif:** mobile di Popover dari bawah. Tablet dan desktop: header menampilkan breadcrumb horizontal biasa ("ESS / Personal / Cuti Saya") dan panel ini hanya muncul untuk mobile; chip menu lain pindah ke [SideNav](../SideNav). *(usulan)*

**Yang disediakan konsumen:** daftar tingkat (label, keterangan, tujuan), menu saudara, handler pindah dan alih aplikasi.
