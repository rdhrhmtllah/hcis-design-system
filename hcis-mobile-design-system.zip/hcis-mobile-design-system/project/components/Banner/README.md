Pita informasi di puncak halaman untuk keadaan yang memengaruhi seluruh layar. Saat ini ada satu: **offline**.

**Susunan:** tinggi minimal 48px, isian `ev-wait-bg`, garis bawah 1,5px oranye muda, ikon sinyal terputus `ev-wait-ink`, judul ("Kamu sedang offline", 13px bobot 700), keterangan terakhir diperbarui, dan tombol "Coba lagi" di kanan.

**Perilaku:** muncul saat koneksi hilang dan menggulir bersama isi halaman. "Coba lagi" menjalankan pemeriksaan ulang; bila berhasil, banner hilang dan toast "Kembali online" muncul.

**State:** tampil, memeriksa ulang (tombol memuat), hilang. State untuk galat server dan pemeliharaan belum dirancang.

**Yang disediakan konsumen:** keadaan koneksi, waktu pembaruan terakhir, dan handler coba lagi.

**Jangan:** memakai banner untuk pesan satu kali (pakai `Toast`) atau menutupi tombol navigasi.

**Responsif:** Mobile: penuh lebar di bawah header. Desktop: penuh lebar area isi (bukan layar), tombol tutup tetap 44px.
