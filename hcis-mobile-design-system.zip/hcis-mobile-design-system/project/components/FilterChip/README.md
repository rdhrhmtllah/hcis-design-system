Chip pilihan untuk menyaring daftar: modul (ESS, TPM, LMS), status (Semua 7, Disetujui 5), dan periode. Disalin dari halaman referensi. Berbeda dari [StatusChip](../StatusChip) yang hanya menyatakan status dan tidak bisa diketuk.

**Bentuk:** tinggi visual 36px dengan area ketuk 44px (perluasan `::after`), `ev-r-xl`, label 13/700, padding 14px. Jumlah ditulis setelah label dengan angka tabular ("Semua 7").

**Pada latar terang (Riwayat cuti):** normal putih dengan garis 1px `ev-purple-150` dan teks `ev-purple-800`; terpilih `ev-purple-600` dengan teks putih.
**Pada latar ungu tua (Menu):** normal kaca (putih 12%, garis putih 16%) dengan teks putih; terpilih `ev-gold` dengan teks `ev-gold-ink`.

**Barisan:** bergulir mendatar di mobile tanpa batang gulir, dengan pinggir 16px; membungkus ke baris berikut di tablet dan desktop. Satu pilihan aktif sekaligus kecuali dinyatakan "pilih banyak" (centang kecil di awal label).

**Perilaku:** `aria-pressed` pada tiap chip; panah memindah fokus, Spasi memilih. Saat filter menghasilkan nol baris, tampilkan [EmptyState](../EmptyState) dan chip tetap aktif; sediakan "Atur ulang".

**State:** normal, hover (naik 1px, latar `ev-purple-50` pada latar terang), fokus (cincin 2px), terpilih, nonaktif (pudar 55%).

**Responsif:** sama; di desktop barisan chip ditaruh di atas [DataTable](../DataTable).

**Yang disediakan konsumen:** daftar opsi dengan jumlah, opsi terpilih, handler.
