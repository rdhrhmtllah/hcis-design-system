Berpindah halaman pada daftar panjang, plus jejak halaman (breadcrumb). Dibuat besar dan jelas agar mudah dibidik dengan mouse maupun jari. **Usulan** untuk tablet dan desktop; mobile memakai "Muat lagi".

**Pagination (desktop)**
- **Bilah:** kartu putih `ev-r-xl` dengan bayangan `ev-sh-row`, padding 12px, dua sisi: kiri ringkasan dan pilihan baris per halaman, kanan kontrol halaman.
- **Ringkasan:** "Menampilkan **11 sampai 20** dari **34**", angkanya tebal. **Baris per halaman:** kapsul pilihan 10, 20, 50.
- **Kontrol:** tombol "Sebelumnya" dan "Berikutnya" berlabel (tinggi 44px, ikon panah), nomor halaman 44px, dan "…" untuk rentang yang diringkas. Halaman aktif: `ev-purple-600`, teks putih, tepi bawah 3px `ev-purple-800`, radius `ev-r-lg`, sedikit terangkat. Halaman lain: transparan, hover `ev-purple-50`.
- **Rentang panjang:** selalu tampilkan halaman pertama, terakhir, dan dua tetangga halaman aktif: `1 … 5 6 7 … 12`.
- **Tombol nonaktif:** "Sebelumnya" di halaman pertama dan "Berikutnya" di halaman terakhir tampil pudar 45%, tetap terlihat (tidak disembunyikan) agar tata letak tidak bergeser.

**Tablet:** versi ringkas: tombol panah ubin `ev-r-md` 44px di kiri dan kanan, di tengah "Halaman **2** dari **4**" yang bisa diketuk untuk membuka pilihan halaman.

**Mobile:** tidak ada nomor halaman. Ringkasan "Menampilkan 10 dari 34" dengan bilah kemajuan tipis ([ProgressBar](../ProgressBar)) dan tombol lebar penuh "Muat 10 lagi" (kontur ungu, tinggi 52px). Setelah semua termuat: teks "Semua pengajuan sudah tampil".

**Breadcrumb**
- Bilah putih (`ev-r-xl`, `ev-sh-row`, tinggi 40px) berisi ubin rumah 28px `ev-r-md`, tautan `ev-purple-800` 600, pemisah panah `ev-ink-3`, dan halaman saat ini dalam ubin `ev-r-md` `ev-purple-100` (`aria-current="page"`, bukan tautan).
- Di tablet dipotong menjadi "… / Induk / Saat ini". Di mobile diganti tombol kembali di [PageHeader](../PageHeader).

**State nomor:** normal, hover, fokus (cincin 2px `ev-purple-600`), aktif, nonaktif, ditekan (turun 1px).

**Perilaku:** panah kiri dan kanan memindah fokus antar nomor, Enter memilih. Pindah halaman mengembalikan gulir ke atas daftar dan fokus ke judul daftar. Menyimpan halaman di alamat (`?page=2`) agar bisa dibagikan dan tombol kembali browser bekerja.

**Aksesibilitas:** `<nav aria-label="Halaman">`, nomor aktif `aria-current="page"`, tombol berlabel "Halaman 2".

**Yang disediakan konsumen:** total, ukuran halaman, halaman aktif, handler.
