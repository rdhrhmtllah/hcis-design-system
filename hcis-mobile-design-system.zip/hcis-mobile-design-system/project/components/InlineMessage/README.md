Pesan yang menetap di dalam halaman, dekat bagian yang dibahas: galat formulir, peringatan kuota, aturan, konfirmasi. Berbeda dari [Toast](../Toast) yang hilang sendiri dan [Banner](../Banner) yang berlaku untuk seluruh halaman.

**Bentuk:** mengikuti kartu status pada halaman (lampiran terpasang, kartu menunggu): latar tint, **garis 1px** pasangan tint-nya, `ev-r-lg`, padding 12px 14px. Ikon polos 20px di kiri (warna ink), judul `body-strong` 14/700, isi `body` 14/500. Tanpa ubin, tanpa garis aksen, tanpa bayangan.

| Jenis | Latar | Garis | Teks dan ikon |
|---|---|---|---|
| Info | `ev-purple-50` | `ev-purple-edge` | `ev-purple-800` |
| Berhasil | `ev-ok-bg` | `ev-ok-edge` | `ev-ok-ink` |
| Peringatan | `ev-wait-bg` | `ev-wait-edge` | `ev-wait-ink` |
| Galat | `ev-no-bg` | `ev-no-edge` | `ev-no-ink` |

Kontras teks 6,5 sampai 7,9:1. Jenis tersampaikan lewat ikon dan kata-kata, tidak hanya warna.

**Aksi:** tautan teks 14/700 sewarna teks pesan, bergaris bawah, di bawah isi, jarak 16px, maksimal dua; area ketuk 44px. Pakai kata kerja ("Pilih jenis cuti lain").

**Boleh ditutup:** tombol x 44px hanya untuk pesan yang aman diabaikan (info). Galat dan peringatan hilang saat masalahnya selesai.

**Tanpa judul:** untuk pesan satu kalimat; dipakai juga sebagai galat di bawah bidang formulir.

**Aksesibilitas:** galat dan peringatan `role="alert"`; info dan berhasil `role="status"`.

**Responsif:** penuh lebar wadahnya; di desktop dibatasi lebar kolom formulir. *(usulan)*

**Yang disediakan konsumen:** jenis, judul (opsional), isi, aksi, boleh-ditutup.
