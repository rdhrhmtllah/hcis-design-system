Kontrol pilihan. Yang utama dan **berasal dari halaman** adalah **kartu pilihan** (jenis cuti: Tahunan, Sakit, Khusus, Tanpa gaji). Kotak centang, radio, dan sakelar belum ada di halaman; bentuknya diturunkan dari pola yang sama dan berstatus usulan.

**Kartu pilihan**
- Kisi 2 kolom, jarak 8px, tinggi minimal 84px, padding 10px, `ev-r-lg`, garis 2px.
- **Tidak dipilih:** latar `ev-white`, garis `ev-purple-150`. **Dipilih:** latar `ev-purple-50`, garis `ev-purple-600`, dan lencana centang 20px `ev-r-md` `ev-purple-600` di pojok kanan atas (centang putih 4px).
- Isi: ubin ikon 30px `ev-r-md` tint dengan garis 1px (Tahunan ungu, Sakit mawar, Khusus hijau, Tanpa gaji oranye), judul 14/700, keterangan 12/500 `ev-ink-2`.
- `aria-pressed` pada tiap kartu; satu terpilih sekaligus. Ditekan: turun 1px.

**Kotak centang (usulan):** 22px, `ev-r-sm`, garis 2px `ev-purple-300`; terpilih `ev-purple-600` dengan centang putih. **Radio (usulan):** lingkaran 22px, terpilih bertitik `ev-purple-600` 10px. **Sakelar (usulan):** 44 x 26px, mati `ev-purple-150`, nyala `ev-purple-600`, kenop putih, geser dengan `ev-ease-spring`.

**Area ketuk:** seluruh baris (termasuk label) minimal 44px.

**State:** normal, hover (garis `ev-purple-300`), fokus (cincin 2px `ev-purple-600`), terpilih, nonaktif (pudar 55%), galat (garis `ev-no-dot` dan pesan).

**Aturan:** sakelar hanya untuk pengaturan yang langsung berlaku; pilihan di formulir yang butuh tombol kirim memakai kartu pilihan atau kotak centang.

**Responsif:** kartu pilihan 2 kolom di mobile, empat kolom sebaris di desktop. *(usulan)*

**Yang disediakan konsumen:** opsi (ikon, judul, keterangan), nilai, handler.
