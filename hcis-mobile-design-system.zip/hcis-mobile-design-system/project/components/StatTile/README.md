Kotak angka berwarna untuk ringkasan di dalam panel atau kartu: "12 hari cuti per tahun", "Berjalan 2". Berbeda dari [StatCard](../StatCard) yang berdiri sendiri di dasbor, StatTile kecil, tanpa bayangan kartu, dan warnanya mengikuti nada modul.

**Dua bentuk (keduanya ada di halaman):**
- **Angka besar** (Ketentuan): angka Bricolage 28/800, rapat (`letter-spacing:-.5px`), warna tinta nada; label 12/600 `ev-ink` di bawah. Padding 12, `ev-r-xl`, garis 1px tepi nada. Tiga tile berjajar rata (`flex:1`, jarak `ev-sp-8`).
- **Hitungan** (Aktivitas): label di atas 12/600 tinta nada, angka Bricolage 26/800 `ev-ink` di bawah. `ev-r-lg`, padding 9x12, garis 1px, bayangan `ev-sh-pop` bila mengambang di atas panel.

**Nada (dipilih dari arti, bukan selera):**
| Nada | Isian | Tepi | Tinta | Arti |
|---|---|---|---|---|
| Ungu | `ev-purple-100` | `ev-purple-edge` | `ev-purple-800` | sedang berjalan, umum |
| Hijau | `ev-ok-bg` | `ev-ok-edge` | `ev-ok-ink` | selesai, jatah, aman |
| Biru | `ev-info-bg` | `ev-info-edge` | `ev-info-ink` | terjadwal, informasi |
| Oranye | `ev-wait-bg` | `ev-wait-edge` | `ev-wait-ink` | menunggu, perlu perhatian |
| Mawar | `ev-no-bg` | `ev-no-edge` | `ev-no-ink` | bermasalah, perlu tindakan |

Di halaman, tile ungu memakai tepi `#C4B6F2`; di DS dipadatkan ke `ev-purple-edge` (`#c9bfef`).

**Aturan:** angka selalu bersama satuan atau label; "12" saja tidak boleh. Maksimal empat tile sebaris; lebih dari itu pakai [DataTable](../DataTable) atau StatCard. Tidak diketuk; bila perlu diketuk, bungkus dengan tombol dan beri fokus 2px `ev-purple-600`.

**State:** normal, memuat ([Skeleton](../Skeleton) dengan tinggi sama), nol (angka "0", tetap tampil).

**Responsif:** mobile tiga kolom sama lebar; bila label tidak muat dua baris, turun ke satu kolom. Tablet dan desktop: lebar tetap sampai 160px lalu dibungkus. *(usulan)*

**Yang disediakan konsumen:** angka, label, nada.
