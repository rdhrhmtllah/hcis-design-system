Unggah dan daftar lampiran (surat dokter dan bukti pendukung). Disalin dari kartu "Surat dokter" pada halaman Ajukan cuti.

**Dalam kartu bernomor:** kartu putih `ev-r-2xl`, lencana nomor 24px `ev-purple-600`, judul `title-s`.

**Zona unggah (belum ada berkas):** tombol penuh lebar tinggi 60px, `ev-r-lg`, garis putus-putus 2px `ev-dash`, latar `ev-field-bg`; ikon unggah dan label "Unggah foto / PDF" `ev-purple-800` 14/700. Ditekan: turun 1px.

**Berkas terpasang:** baris `ev-r-lg` berlatar `ev-ok-bg` dengan garis 1px `ev-ok-edge`; ubin putih 40px `ev-r-md` berikon berkas `ev-ok-ink`; nama berkas 14/700 `ev-ink`; keterangan "240 KB · terlampir" 12/500 `ev-ok-ink`; tombol hapus 44px dengan `aria-label="Hapus lampiran"`.

**Mengunggah (usulan):** baris berlatar `ev-purple-50` dengan garis 1px `ev-purple-edge`, keterangan "mengunggah 62%", bilah kemajuan 4px di dasar ([ProgressBar](../ProgressBar)).
**Gagal (usulan):** baris `ev-no-bg` dengan garis 1px `ev-no-edge`, pesan `ev-no-ink` yang menyebut sebab ("Ukuran 8 MB melebihi batas 5 MB") dan tombol "Coba lagi".

**Aturan:** batas jenis dan ukuran ditulis di teks bantu sebelum memilih. Di desktop zona unggah menerima seret-lepas (hover dan seret: garis `ev-purple-600`).

**Wajib:** bila jenis cuti mewajibkan lampiran, tombol utama menyebut "Lampirkan surat dokter" sampai terpasang.

**Responsif:** penuh lebar kartu di semua ukuran.

**Yang disediakan konsumen:** aturan jenis dan ukuran, handler unggah dan hapus.
