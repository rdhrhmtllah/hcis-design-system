Satu baris notifikasi di panel Notifikasi. Disalin dari halaman referensi.

**Anatomi:** kartu putih `ev-r-xl` dengan `ev-sh-row`, tinggi 72px, padding 14px. Dari kiri: ubin ikon 40px `ev-r-md` berlatar tint dengan garis 1px (pasangan `-bg`, `-edge`, `-ink`), lalu judul 14px dan satu baris keterangan 12px, lalu titik belum dibaca.

**Warna ubin menurut jenis**
| Jenis | Latar | Garis | Ikon |
|---|---|---|---|
| Cuti | `ev-purple-100` | `ev-purple-edge` | `ev-purple-800` |
| Presensi | `ev-wait-bg` | `ev-wait-edge` | `ev-wait-ink` |
| Pelatihan | `ev-info-bg` | `ev-info-edge` | `ev-info-ink` |
| Hasil, disetujui | `ev-ok-bg` | `ev-ok-edge` | `ev-ok-ink` |

**Belum dibaca:** garis ungu 3px di tepi kiri (`ev-purple-600`), judul 700, dan titik 10px `ev-purple-600` di kanan. **Sudah dibaca:** tanpa garis dan titik, judul 600.

**Keterangan:** waktu relatif 700 `ev-purple-accent`, lalu titik tengah dan rincian (kode atau pokok isi) 12/500 `ev-ink-2`. Satu baris, dipotong dengan elipsis.

**Kelompok:** judul 12/600 huruf kapital `ev-purple-accent` ("BARU", "SEBELUMNYA") dengan jarak 8px ke baris.

**Gesture (sentuh):** panel di bawah baris muncul mengikuti jari. Geser kanan 80px atau lebih: latar `ev-gold`, "Dibaca" `ev-ok-ink`. Geser kiri 80px atau lebih: latar `ev-no-edge`, "Hapus" `ev-no-ink`, lalu toast dengan "Urungkan". Tombol "Tandai dibaca" kapsul emas di [PageHeader](../PageHeader) menjadi jalan alternatif.

**State:** belum dibaca, sudah dibaca, ditekan (turun 1px), fokus (cincin 2px `ev-purple-600`), digeser, memuat ([Skeleton](../Skeleton)), kosong ([EmptyState](../EmptyState)).

**Jangan:** menghapus tanpa jalan Urungkan, atau menyampaikan jenis hanya dengan warna ubin (ikon selalu ada).

**Responsif:** mobile penuh lebar. Tablet dan desktop (usulan): panel kanan atau popover selebar 380px; tanpa gesture, ikon "Tandai dibaca" dan "Hapus" muncul di kanan saat hover atau fokus baris.

**Yang disediakan konsumen:** jenis, judul, waktu, rincian, status baca.
