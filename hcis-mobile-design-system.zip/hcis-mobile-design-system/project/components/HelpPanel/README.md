Isi panel Bantuan: tiga tab (Tur, Panduan, PIC Modul) di bawah kepala berwarna. Menyusun [TourCard](../TourCard), [GuideRow](../GuideRow), dan [ContactRow](../ContactRow). Di halaman referensi dibuka dari ikon bantuan di header dan tampil dalam [Popover](../Popover) (mobile: dari bawah, hampir penuh).

**Kepala (milik panel):** gradien `ev-purple-900` ke `ev-purple-700`, sudut bawah `ev-r-3xl`, judul "Bantuan" Bricolage 22/700 putih, keterangan 12/500 `ev-purple-150`, dan pil emas di kanan (tinggi 30, `ev-r-lg`, `ev-gold` dengan teks `ev-gold-ink` 12/600) berisi konteks, misalnya "Cuti Saya".

**Tab:** pembungkus tinggi 42, `ev-r-xl`, putih 16% dengan garis putih 20%; indikator putih tinggi 34 `ev-r-lg` bergeser dengan `ev-ease-spring` (`ev-t-mid`) di bawah label; label aktif `ev-purple-800`, tidak aktif putih, 13/700. Ini variasi di atas gradien dari [Tabs](../Tabs); jangan memakai versi kaca ini di atas latar terang.

**Isi per tab:**
- **Tur:** satu TourCard dengan catatan di bawahnya.
- **Panduan:** daftar GuideRow dengan catatan "Panduan yang belum tersedia akan muncul otomatis begitu dirilis."
- **PIC Modul:** kalimat pengantar "Ketuk modul untuk melihat kontak PIC." lalu daftar ContactRow.

Pergantian tab: isi lama memudar dan isi baru naik 8px dengan baris masuk bergantian 50ms (`motion.md`). Gulir di dalam isi; kepala tidak ikut bergulir.

**Aksesibilitas:** `role="tablist"` dan `role="tab"` dengan `aria-selected`; isi `role="tabpanel"`. Tombol kanan-kiri berpindah antar tab.

**State:** setiap tab memiliki memuat ([Skeleton](../Skeleton) tiga baris), kosong, dan galat ([InlineMessage](../InlineMessage) dengan "Coba lagi").

**Responsif:** mobile sheet hampir penuh. Tablet: panel samping kanan `ev-w-panel`. Desktop: panel melayang di bawah ikon bantuan, `ev-w-panel`. Isi dan kepala sama. *(usulan)*

**Yang disediakan konsumen:** konteks halaman (pil), data tur, daftar panduan, daftar PIC.
