Segmen untuk berpindah antar tampilan yang setara di satu halaman: "Umum · 3 | Khusus · 8" (Jenis cuti), "Semua | Belum dibaca · 3" (Notifikasi). Disalin dari halaman referensi; **satu-satunya bentuk tab di sistem ini**, termasuk di tablet dan desktop.

**Bentuk:** wadah tinggi 46px, padding 3px, `ev-r-2xl`, latar `ev-purple-100`. Penanda di dalamnya `ev-purple-600`, `ev-r-xl`, tinggi 40px, dengan bayangan lembut ungu; penanda **bergeser** ke segmen terpilih (`ev-t-mid`, `ev-ease-spring`), bukan berganti tiba-tiba. Label 14/700: putih di segmen terpilih, `ev-purple-800` di segmen lain. Jumlah ditulis setelah titik tengah ("Umum · 3").

**Pada latar ungu tua** (panel Notifikasi): wadah kaca (putih 14%), penanda putih, label terpilih `ev-purple-800`, label lain putih.

**Jumlah segmen:** dua sampai empat dengan lebar sama. Lebih dari empat pilihan, pakai [FilterChip](../FilterChip) yang bisa digulir.

**Perilaku:** peran `tablist`, `tab`, `tabpanel`. Panah kiri dan kanan pindah dan memilih, `Home` dan `End` ke ujung. Isi panel berganti dengan pudar 150ms, tanpa geser mendatar (geser dipakai kartu).

**State:** normal, hover (label `ev-purple-600`), fokus (cincin 2px `ev-purple-600`), terpilih, nonaktif.

**Berbeda dari [SummaryChip](../SummaryChip):** SummaryChip menyaring status di header Cuti Saya; Tabs memisahkan tampilan halaman.

**Responsif:** mobile penuh lebar. Tablet dan desktop: lebar mengikuti isi (minimal 120px per segmen), rata kiri di bawah [PageHeader](../PageHeader). *(usulan)*

**Yang disediakan konsumen:** daftar segmen (label, jumlah), segmen aktif, handler.
