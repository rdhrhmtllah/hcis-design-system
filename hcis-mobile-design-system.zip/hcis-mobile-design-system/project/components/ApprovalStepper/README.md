Menunjukkan tahap persetujuan sebuah pengajuan. Ada dua bentuk dengan arti yang sama.

**Bentuk**
- **Mendatar** di dalam kartu pengajuan: 3 atau 4 simpul (Terkirim, Atasan, HR, Selesai) dengan garis penghubung dan satu kalimat status di atasnya.
- **Tegak (linimasa)** di halaman Detail: tiap tahap punya judul, keterangan, dan waktu.

**State simpul:** selesai (`ev-purple-600` dengan centang), aktif (cincin `ev-wait-dot`), belum (garis abu, nomor), ditolak (`ev-no-dot`, tanda silang), dibatalkan (abu, tanda hubung). Garis di antara simpul ungu bila sudah dilalui, abu bila belum.

**Teks keterangan** menjelaskan keadaan, bukan hanya nama tahap: "Menunggu keputusan · maks. 2 hari kerja", "Belum diproses" untuk tahap yang belum dicapai, "Tidak dilanjutkan" untuk pengajuan yang ditolak atau dibatalkan.

**Yang disediakan konsumen:** daftar tahap, posisi tahap aktif, dan akhir (disetujui, ditolak, dibatalkan).

**Jangan:** memakai warna saja untuk menyatakan tahap (selalu ada nomor, centang, atau tanda), dan jangan menandai tahap yang belum tercapai sebagai "belum diproses" pada pengajuan yang sudah ditolak.

**Responsif:** Mobile: vertikal di dalam Detail. Desktop (usulan): bisa horizontal bila ruang lebih dari 640px; tiap langkah tetap memuat nama, status, dan waktu.
